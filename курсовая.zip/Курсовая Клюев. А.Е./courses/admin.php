<?php
// admin.php - панель администратора курсов C#

require_once __DIR__ . '/src/helpers.php';

// Проверяем авторизацию
if (!isLoggedIn()) {
    redirect('3.php');
}

// Проверяем права администратора
if (!isAdmin()) {
    die("Доступ запрещен. Только для администраторов курсов.");
}

// Обработка действий
$action = $_GET['action'] ?? '';
$userId = $_GET['id'] ?? 0;
$message = '';
$messageType = '';

// Удаление пользователя
if ($action === 'delete' && $userId) {
    if (deleteUser($userId)) {
        $message = 'Пользователь успешно удален';
        $messageType = 'success';
    } else {
        $message = 'Ошибка при удалении пользователя';
        $messageType = 'error';
    }
}

// Обновление роли
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_role'])) {
    $userId = $_POST['user_id'];
    $roleId = $_POST['role_id'];
    
    if (updateUserRole($userId, $roleId)) {
        $message = 'Роль пользователя обновлена';
        $messageType = 'success';
    } else {
        $message = 'Ошибка при обновлении роли';
        $messageType = 'error';
    }
}

// Получаем всех пользователей
$users = getAllUsers();
$roles = getAllRoles();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Панель администратора курсов C#</title>
    <style>
        :root {
            --dark-blue: #0a192f;
            --medium-blue: #172a45;
            --light-blue: #1d3657;
            --accent-blue: #64ffda;
            --text-light: #ccd6f6;
            --text-gray: #8892b0;
            --error-red: #ff6b6b;
            --success-green: #48bb78;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', 'SF Pro Display', -apple-system, sans-serif;
            background: linear-gradient(135deg, var(--dark-blue) 0%, #0d1b2a 100%);
            color: var(--text-light);
            min-height: 100vh;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        header {
            background: linear-gradient(135deg, var(--medium-blue) 0%, var(--dark-blue) 100%);
            color: var(--text-light);
            padding: 25px 0;
            margin-bottom: 30px;
            border-radius: 0 0 15px 15px;
            border-bottom: 3px solid var(--accent-blue);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .admin-title {
            font-size: 28px;
            font-weight: 700;
            color: var(--accent-blue);
            letter-spacing: 0.5px;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .admin-title:before {
            content: '{ }';
            font-family: 'Courier New', monospace;
            font-size: 24px;
            color: var(--accent-blue);
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .nav-menu {
            background: rgba(23, 42, 69, 0.9);
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 35px;
            border: 1px solid rgba(100, 255, 218, 0.1);
            backdrop-filter: blur(10px);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }
        
        .nav-menu ul {
            list-style: none;
            display: flex;
            gap: 25px;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        .nav-menu a {
            color: var(--text-gray);
            text-decoration: none;
            padding: 12px 25px;
            border-radius: 8px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
            border: 1px solid transparent;
        }
        
        .nav-menu a:hover {
            background: rgba(100, 255, 218, 0.1);
            color: var(--accent-blue);
            border-color: rgba(100, 255, 218, 0.3);
            transform: translateY(-2px);
        }
        
        .message {
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            text-align: center;
            font-weight: 600;
            animation: slideIn 0.5s ease;
            backdrop-filter: blur(10px);
            border: 1px solid;
        }
        
        @keyframes slideIn {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        
        .success {
            background: rgba(72, 187, 120, 0.1);
            color: var(--success-green);
            border-color: rgba(72, 187, 120, 0.3);
        }
        
        .error {
            background: rgba(255, 107, 107, 0.1);
            color: var(--error-red);
            border-color: rgba(255, 107, 107, 0.3);
        }
        
        .users-table {
            background: rgba(23, 42, 69, 0.9);
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(100, 255, 218, 0.1);
            backdrop-filter: blur(10px);
            margin-bottom: 40px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th {
            background: rgba(10, 25, 47, 0.8);
            color: var(--text-light);
            padding: 20px;
            text-align: left;
            font-weight: 600;
            font-size: 15px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 2px solid rgba(100, 255, 218, 0.2);
        }
        
        td {
            padding: 20px;
            border-bottom: 1px solid rgba(100, 255, 218, 0.1);
            color: var(--text-light);
        }
        
        tr:hover {
            background-color: rgba(100, 255, 218, 0.05);
        }
        
        .role-badge {
            display: inline-block;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 8px;
        }
        
        .role-admin {
            background: rgba(220, 53, 69, 0.2);
            color: #ff6b6b;
            border: 1px solid rgba(220, 53, 69, 0.3);
        }
        
        .role-user {
            background: rgba(72, 187, 120, 0.2);
            color: var(--success-green);
            border: 1px solid rgba(72, 187, 120, 0.3);
        }
        
        .actions {
            display: flex;
            gap: 12px;
        }
        
        .btn {
            padding: 10px 18px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            letter-spacing: 0.5px;
            text-transform: uppercase;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        .btn-view {
            background: rgba(23, 162, 184, 0.2);
            color: #17a2b8;
            border: 1px solid rgba(23, 162, 184, 0.3);
        }
        
        .btn-edit {
            background: rgba(255, 193, 7, 0.2);
            color: #ffc107;
            border: 1px solid rgba(255, 193, 7, 0.3);
        }
        
        .btn-delete {
            background: rgba(220, 53, 69, 0.2);
            color: var(--error-red);
            border: 1px solid rgba(220, 53, 69, 0.3);
        }
        
        .btn-save {
            background: rgba(72, 187, 120, 0.2);
            color: var(--success-green);
            border: 1px solid rgba(72, 187, 120, 0.3);
        }
        
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        
        .stat-card {
            background: rgba(23, 42, 69, 0.8);
            padding: 25px;
            border-radius: 15px;
            text-align: center;
            border: 1px solid rgba(100, 255, 218, 0.1);
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            border-color: var(--accent-blue);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }
        
        .stat-number {
            font-size: 42px;
            font-weight: 700;
            color: var(--accent-blue);
            margin: 15px 0;
            font-family: 'SF Mono', monospace;
        }
        
        .stat-label {
            color: var(--text-gray);
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 600;
        }
        
        select {
            background: rgba(10, 25, 47, 0.8);
            color: var(--text-light);
            border: 1px solid rgba(100, 255, 218, 0.3);
            border-radius: 8px;
            padding: 10px 15px;
            font-family: 'SF Mono', monospace;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 14px;
            width: 100%;
            max-width: 200px;
        }
        
        select:focus {
            outline: none;
            border-color: var(--accent-blue);
            box-shadow: 0 0 0 3px rgba(100, 255, 218, 0.1);
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            justify-content: center;
            align-items: center;
            z-index: 1000;
            backdrop-filter: blur(5px);
        }
        
        .modal-content {
            background: rgba(23, 42, 69, 0.95);
            padding: 40px;
            border-radius: 20px;
            max-width: 600px;
            width: 90%;
            border: 1px solid rgba(100, 255, 218, 0.2);
            box-shadow: 0 25px 80px rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(10px);
        }
        
        .modal h3 {
            margin-bottom: 25px;
            color: var(--accent-blue);
            font-size: 24px;
            font-weight: 700;
            border-bottom: 2px solid rgba(100, 255, 218, 0.2);
            padding-bottom: 15px;
        }
        
        .modal-actions {
            display: flex;
            justify-content: flex-end;
            gap: 15px;
            margin-top: 30px;
        }
        
        footer {
            text-align: center;
            margin-top: 60px;
            padding: 30px;
            color: var(--text-gray);
            border-top: 1px solid rgba(100, 255, 218, 0.1);
            font-size: 14px;
            backdrop-filter: blur(10px);
            border-radius: 10px;
            background: rgba(23, 42, 69, 0.5);
        }
        
        .code-id {
            font-family: 'SF Mono', monospace;
            color: var(--accent-blue);
            font-size: 12px;
            margin-left: 5px;
            opacity: 0.8;
        }
        
        .current-user-badge {
            display: inline-block;
            background: rgba(100, 255, 218, 0.1);
            color: var(--accent-blue);
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
            margin-left: 10px;
            border: 1px solid rgba(100, 255, 218, 0.2);
        }
        
        .header-btn {
            padding: 10px 20px;
            background: rgba(100, 255, 218, 0.1);
            color: var(--accent-blue);
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s;
            border: 1px solid rgba(100, 255, 218, 0.2);
        }
        
        .header-btn:hover {
            background: rgba(100, 255, 218, 0.2);
            transform: translateY(-2px);
        }
        
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                gap: 20px;
                text-align: center;
            }
            
            .nav-menu ul {
                flex-direction: column;
                align-items: center;
            }
            
            table {
                display: block;
                overflow-x: auto;
            }
            
            .actions {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
            
            .stats {
                grid-template-columns: 1fr;
            }
            
            .modal-content {
                padding: 25px;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="header-content">
                <h1 class="admin-title">Панель администратора курсов C#</h1>
                <div class="user-info">
                    <span>Администратор: <strong><?= htmlspecialchars($_SESSION['user']['name']) ?></strong></span>
                    <a href="3-3.php" class="header-btn">👨‍💻 Профиль</a>
                    <a href="index.php" class="header-btn">🏠 На сайт</a>
                    <a href="src/actions/logout.php" class="header-btn">🚪 Выйти</a>
                </div>
            </div>
        </div>
    </header>
    
    <div class="container">
        <!-- Меню -->
        <nav class="nav-menu">
            <ul>
                <li><a href="admin.php">👥 Управление студентами</a></li>
                <li><a href="#">📊 Статистика курсов</a></li>
                <li><a href="#">⚙️ Настройки системы</a></li>
                <li><a href="#">📝 Журнал активности</a></li>
                <li><a href="#">🎓 Сертификаты</a></li>
            </ul>
        </nav>
        
        <!-- Сообщения -->
        <?php if ($message): ?>
            <div class="message <?= $messageType ?>">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>
        
        <!-- Статистика -->
        <div class="stats">
            <div class="stat-card">
                <div class="stat-number"><?= count($users) ?></div>
                <div class="stat-label">Всего студентов</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">
                    <?= count(array_filter($users, fn($u) => $u['role_id'] == 1)) ?>
                </div>
                <div class="stat-label">Администраторов</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">
                    <?= count(array_filter($users, fn($u) => $u['role_id'] == 2)) ?>
                </div>
                <div class="stat-label">Активных учеников</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">95%</div>
                <div class="stat-label">Успеваемость курса</div>
            </div>
        </div>
        
        <!-- Таблица пользователей -->
        <div class="users-table">
            <table>
                <thead>
                    <tr>
                        <th>ID студента</th>
                        <th>Имя</th>
                        <th>Email</th>
                        <th>Роль / Статус</th>
                        <th>Дата регистрации</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td>
                                <span class="code-id">#DEV<?= $user['user_id'] ?></span>
                            </td>
                            <td>
                                <strong><?= htmlspecialchars($user['name']) ?></strong>
                                <?php if ($user['user_id'] == $_SESSION['user']['user_id']): ?>
                                    <span class="current-user-badge">Текущий пользователь</span>
                                <?php endif; ?>
                            </td>
                            <td style="font-family: 'SF Mono', monospace;"><?= htmlspecialchars($user['email']) ?></td>
                            <td>
                                <span class="role-badge <?= $user['role_id'] == 1 ? 'role-admin' : 'role-user' ?>">
                                    <?= $user['role_name'] ?? ($user['role_id'] == 1 ? 'Администратор' : 'Студент') ?>
                                </span>
                                <br>
                                <form method="POST" action="" style="margin-top: 10px;">
                                    <input type="hidden" name="user_id" value="<?= $user['user_id'] ?>">
                                    <select name="role_id" onchange="this.form.submit()">
                                        <option value="1" <?= $user['role_id'] == 1 ? 'selected' : '' ?>>Администратор курсов</option>
                                        <option value="2" <?= $user['role_id'] == 2 ? 'selected' : '' ?>>Студент</option>
                                        <option value="3" <?= $user['role_id'] == 3 ? 'selected' : '' ?>>Куратор</option>
                                    </select>
                                    <input type="hidden" name="update_role" value="1">
                                </form>
                            </td>
                            <td style="font-family: 'SF Mono', monospace;">
                                <?php 
                                if (isset($user['created_at'])) {
                                    echo date('d.m.Y', strtotime($user['created_at']));
                                } else {
                                    echo date('d.m.Y');
                                }
                                ?>
                            </td>
                            <td>
                                <div class="actions">
                                    <button class="btn btn-view" onclick="viewUser(<?= $user['user_id'] ?>, '<?= htmlspecialchars($user['name']) ?>')">
                                        📊 Статистика
                                    </button>
                                    <?php if ($user['user_id'] != $_SESSION['user']['user_id']): ?>
                                        <button class="btn btn-delete" onclick="confirmDelete(<?= $user['user_id'] ?>, '<?= htmlspecialchars($user['name']) ?>')">
                                            🗑️ Удалить
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Модальное окно подтверждения удаления -->
        <div id="deleteModal" class="modal">
            <div class="modal-content">
                <h3>Подтверждение удаления студента</h3>
                <p>Вы действительно хотите удалить студента <strong id="userNameToDelete" style="color: var(--accent-blue);"></strong>?</p>
                <p style="color: var(--error-red); font-size: 14px; margin-top: 15px; padding: 10px; background: rgba(255, 107, 107, 0.1); border-radius: 8px; border: 1px solid rgba(255, 107, 107, 0.3);">
                    ⚠️ Внимание! Это действие нельзя отменить. Все данные студента будут удалены безвозвратно.
                </p>
                <div class="modal-actions">
                    <button class="btn" onclick="closeModal()">❌ Отмена</button>
                    <a id="confirmDeleteBtn" class="btn btn-delete">✅ Удалить студента</a>
                </div>
            </div>
        </div>
        
        <!-- Модальное окно просмотра пользователя -->
        <div id="viewModal" class="modal">
            <div class="modal-content">
                <h3>Статистика студента: <span id="viewUserName" style="color: var(--accent-blue);"></span></h3>
                <div id="userDetails" style="line-height: 1.8;">
                    <p>Загрузка информации о студенте...</p>
                    <div style="background: rgba(100, 255, 218, 0.05); padding: 20px; border-radius: 10px; margin-top: 15px; border: 1px solid rgba(100, 255, 218, 0.1);">
                        <p style="color: var(--text-gray); font-size: 14px;">Для полной реализации требуется AJAX запрос к серверу.</p>
                        <p style="color: var(--text-gray); font-size: 14px; margin-top: 10px;">ID студента: <span id="viewUserId" class="code-id"></span></p>
                    </div>
                </div>
                <div class="modal-actions">
                    <button class="btn" onclick="closeModal()">Закрыть</button>
                </div>
            </div>
        </div>
        
        <footer>
            <p>Панель администратора курсов C# | Система управления обучением</p>
            <p style="margin-top: 15px; font-size: 12px; color: var(--text-gray); font-family: 'SF Mono', monospace;">
                &copy; <?= date('Y') ?> C# Courses. Все права защищены. <span style="color: var(--accent-blue);">// Secure Admin Panel</span>
            </p>
        </footer>
    </div>
    
    <script>
        // Функции для модальных окон
        function confirmDelete(userId, userName) {
            document.getElementById('userNameToDelete').textContent = userName;
            document.getElementById('confirmDeleteBtn').href = 'admin.php?action=delete&id=' + userId;
            document.getElementById('deleteModal').style.display = 'flex';
        }
        
        function viewUser(userId, userName) {
            document.getElementById('viewUserName').textContent = userName;
            document.getElementById('viewUserId').textContent = '#DEV' + userId;
            
            // Симуляция данных студента
            const userDetails = `
                <div class="stat-card" style="margin-bottom: 15px; text-align: left; padding: 20px;">
                    <p><strong>ID студента:</strong> <span class="code-id">#DEV${userId}</span></p>
                    <p><strong>Прогресс курса:</strong> <span style="color: var(--accent-blue); font-weight: bold;">65%</span></p>
                    <p><strong>Выполнено уроков:</strong> 13/20</p>
                    <p><strong>Практических заданий:</strong> 18</p>
                    <p><strong>Средний балл:</strong> 4.7/5.0</p>
                    <p><strong>Дата последней активности:</strong> Сегодня, 15:30</p>
                </div>
                <div style="display: flex; gap: 15px; margin-top: 20px;">
                    <button class="btn btn-view" style="flex: 1;">📝 История активности</button>
                    <button class="btn btn-edit" style="flex: 1;">✏️ Редактировать профиль</button>
                </div>
            `;
            
            document.getElementById('userDetails').innerHTML = userDetails;
            document.getElementById('viewModal').style.display = 'flex';
        }
        
        function closeModal() {
            document.getElementById('deleteModal').style.display = 'none';
            document.getElementById('viewModal').style.display = 'none';
        }
        
        // Закрытие модального окна при клике вне его
        window.onclick = function(event) {
            const modals = document.querySelectorAll('.modal');
            modals.forEach(modal => {
                if (event.target == modal) {
                    modal.style.display = 'none';
                }
            });
        }
        
        // Автоматическое скрытие сообщений через 5 секунд
        setTimeout(() => {
            const messages = document.querySelectorAll('.message');
            messages.forEach(msg => {
                msg.style.opacity = '0';
                msg.style.transition = 'opacity 0.5s';
                setTimeout(() => msg.remove(), 500);
            });
        }, 5000);
        
        // Анимация при загрузке
        document.addEventListener('DOMContentLoaded', () => {
            const statCards = document.querySelectorAll('.stat-card');
            statCards.forEach((card, index) => {
                setTimeout(() => {
                    card.style.transform = 'translateY(0)';
                    card.style.opacity = '1';
                }, index * 100);
            });
        });
    </script>
</body>
</html>