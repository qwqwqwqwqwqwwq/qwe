<?php
// Начинаем сессию в самом начале файла
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Подключаем helpers.php для использования функций
require_once __DIR__ . '/src/actions/helpers.php';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="style.css">
    <title>Литература по C# | Курсы программирования</title>
    <style>
        :root {
            --dark-blue: #0a192f;
            --medium-blue: #172a45;
            --light-blue: #1d3657;
            --accent-blue: #64ffda;
            --text-light: #ccd6f6;
            --text-gray: #8892b0;
        }
        
        .body-top {
            background: linear-gradient(135deg, var(--dark-blue) 0%, #0d1b2a 100%);
            color: var(--text-light);
            font-family: 'Segoe UI', 'SF Pro Display', -apple-system, sans-serif;
            min-height: 100vh;
            line-height: 1.6;
        }
        
        header {
            background: linear-gradient(135deg, var(--medium-blue) 0%, var(--dark-blue) 100%);
            padding: 1.5rem 0;
            border-bottom: 2px solid var(--accent-blue);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
            text-align: center; /* Добавлено: центрирование заголовка */
        }
        
        .logo img {
            height: 70px;
            border-radius: 10px;
            border: 2px solid var(--accent-blue);
            padding: 3px;
            background: white;
        }
        
        .title h1 {
            color: var(--accent-blue);
            font-size: 2.3rem;
            font-weight: 700;
            letter-spacing: 0.5px;
            text-shadow: 0 2px 10px rgba(100, 255, 218, 0.2);
            width: 100%; /* Добавлено: занимает всю ширину */
            text-align: center; /* Добавлено: центрирование текста */
            margin: 0; /* Добавлено: убираем отступы по умолчанию */
        }
        
        .nav {
            background: rgba(23, 42, 69, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            padding: 0.5rem;
            margin: 1.5rem auto;
            max-width: 1200px;
            border: 1px solid rgba(100, 255, 218, 0.1);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }
        
        .nav-link {
            color: var(--text-gray) !important;
            background: transparent;
            margin: 0 4px;
            border-radius: 8px;
            border: 1px solid transparent;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            font-weight: 500;
            padding: 0.8rem 1.8rem;
        }
        
        .nav-link:hover {
            color: var(--accent-blue) !important;
            transform: translateY(-2px);
            border-color: rgba(100, 255, 218, 0.3);
            box-shadow: 0 4px 15px rgba(100, 255, 218, 0.1);
        }
        
        .nav-link.active {
            background: rgba(100, 255, 218, 0.1) !important;
            color: var(--accent-blue) !important;
            border-color: var(--accent-blue);
        }
        
        main {
            background: rgba(10, 25, 47, 0.7);
            padding: 2.5rem;
            border-radius: 20px;
            margin: 1.5rem auto;
            max-width: 1200px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(100, 255, 218, 0.1);
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        }
        
        .display-6 {
            color: var(--accent-blue);
            font-size: 3rem;
            margin-bottom: 2.5rem;
            padding-bottom: 1.5rem;
            border-bottom: 2px solid rgba(100, 255, 218, 0.3);
            text-align: center;
            position: relative;
        }
        
        .display-6:after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 50%;
            transform: translateX(-50%);
            width: 150px;
            height: 3px;
            background: var(--accent-blue);
            border-radius: 2px;
        }
        
        .h2 {
            color: var(--accent-blue);
            font-size: 2rem;
            margin: 2.5rem 0 1.5rem;
            padding-left: 1rem;
            border-left: 4px solid var(--accent-blue);
            font-weight: 600;
        }
        
        p {
            color: var(--text-gray);
            line-height: 1.8;
            font-size: 1.15rem;
            margin-bottom: 1.5rem;
        }
        
        /* Стили для книг из первого кода */
        .book-container {
            display: flex;
            align-items: flex-start;
            margin-bottom: 50px;
            flex-wrap: wrap;
            padding: 30px;
            background: rgba(23, 42, 69, 0.4);
            border-radius: 15px;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
            border: 1px solid rgba(100, 255, 218, 0.1);
            transition: transform 0.3s ease;
        }
        
        .book-container:hover {
            transform: translateY(-5px);
            border-color: var(--accent-blue);
        }
        
        .book-text {
            flex: 1;
            min-width: 300px;
            padding: 0 30px;
        }
        
        .book-image {
            max-width: 400px;
            min-width: 320px;
        }
        
        .book-image img {
            width: 100%;
            height: auto;
            border-radius: 12px;
            border: 2px solid rgba(100, 255, 218, 0.3);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
            transition: transform 0.3s ease;
        }
        
        .book-image img:hover {
            transform: scale(1.03);
            border-color: var(--accent-blue);
        }
        
        .reverse {
            flex-direction: row-reverse;
        }
        
        .book-number {
            display: inline-block;
            background: var(--accent-blue);
            color: var(--dark-blue);
            width: 45px;
            height: 45px;
            border-radius: 50%;
            text-align: center;
            line-height: 45px;
            font-weight: bold;
            margin-right: 15px;
            font-size: 1.3rem;
            box-shadow: 0 4px 12px rgba(100, 255, 218, 0.3);
        }
        
        .book-meta {
            background: rgba(100, 255, 218, 0.05);
            border-left: 3px solid var(--accent-blue);
            padding: 1.2rem;
            margin: 1.5rem 0;
            border-radius: 0 8px 8px 0;
        }
        
        .meta-item {
            display: flex;
            align-items: center;
            margin: 0.5rem 0;
            color: var(--text-light);
        }
        
        .meta-icon {
            color: var(--accent-blue);
            margin-right: 10px;
            font-size: 1.2rem;
        }
        
        .level-badge {
            display: inline-block;
            padding: 0.4rem 1.2rem;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
            margin-right: 0.8rem;
            margin-bottom: 0.8rem;
        }
        
        .level-beginner {
            background: rgba(72, 187, 120, 0.15);
            color: #48bb78;
            border: 1px solid rgba(72, 187, 120, 0.3);
        }
        
        .level-intermediate {
            background: rgba(66, 153, 225, 0.15);
            color: #4299e1;
            border: 1px solid rgba(66, 153, 225, 0.3);
        }
        
        .level-advanced {
            background: rgba(237, 100, 166, 0.15);
            color: #ed64a6;
            border: 1px solid rgba(237, 100, 166, 0.3);
        }
        
        .feature-list {
            list-style: none;
            padding-left: 0;
            margin: 1.5rem 0;
        }
        
        .feature-list li {
            margin: 0.8rem 0;
            padding-left: 2rem;
            position: relative;
            color: var(--text-light);
        }
        
        .feature-list li:before {
            content: '✓';
            color: var(--accent-blue);
            position: absolute;
            left: 0;
            font-weight: bold;
        }
        
        .quote {
            font-style: italic;
            color: var(--text-light);
            border-left: 3px solid var(--accent-blue);
            padding-left: 1.5rem;
            margin: 2rem 0;
            font-size: 1.1rem;
        }
        
        .book-highlight {
            background: linear-gradient(120deg, rgba(100, 255, 218, 0.1) 0%, transparent 100%);
            padding: 2rem;
            border-radius: 15px;
            margin: 2rem 0;
            border: 1px solid rgba(100, 255, 218, 0.1);
            text-align: center;
        }
        
        .footer {
            background: linear-gradient(135deg, var(--medium-blue) 0%, var(--dark-blue) 100%);
            color: var(--text-gray);
            padding: 2.5rem 0;
            margin-top: 4rem;
            border-top: 2px solid var(--accent-blue);
            text-align: center;
            font-size: 1.1rem;
        }
        
        @media (max-width: 768px) {
            .book-container, .book-container.reverse {
                flex-direction: column;
                padding: 20px;
            }
            
            .book-image, .book-text {
                width: 100%;
                max-width: 100%;
                padding: 0;
                margin-bottom: 20px;
            }
            
            .book-image {
                min-width: 100%;
            }
            
            .display-6 {
                font-size: 2.2rem;
            }
            
            .h2 {
                font-size: 1.6rem;
            }
            
            .nav-link {
                padding: 0.6rem 1.2rem;
                margin: 2px;
            }
            
            main {
                padding: 1.5rem;
                margin: 1rem;
            }
        }
        
        .flex {
            display: flex;
            flex-direction: column;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .row {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            padding: 1.5rem 0;
        }
        
        .col {
            flex: 1;
            padding: 1rem;
        }
        
        strong {
            color: var(--accent-blue);
        }
    </style>
</head>
<body class="body-top">
<header class="container">
    <!-- ЛОГОТИП УДАЛЕН -->
    <div class="title">
        <h1>Стань профессионалом в C# разработке!</h1>
    </div>
</header>

<div id="menu">
    <nav class="nav nav-pills flex-column flex-sm-row">
        <a class="flex-sm-fill text-sm-center nav-link" href="index.php">Главная</a>
        <a class="flex-sm-fill text-sm-center nav-link" href="1.php">История языка</a>
        <a class="flex-sm-fill text-sm-center nav-link" href="4.php">Отзывы о языке C#</a>
        <a class="flex-sm-fill text-sm-center nav-link active" href="2.php">Литература по C#</a>
        <?php if (isset($_SESSION['user']['user_id'])) : ?>
            <a class="flex-sm-fill text-sm-center nav-link" href="3-3.php"><?= htmlspecialchars($_SESSION['user']['name']) ?></a>
        <?php else : ?>
            <a class="flex-sm-fill text-sm-center nav-link" href="3.php">Войти/Зарегистрироваться</a>
        <?php endif; ?>
    </nav>
</div>

<main class="flex">
    <div class="container">
        <h1 class="display-6">Рекомендованная литература по C#</h1>
        
        <div class="book-highlight">
            <p>Подборка лучших книг для освоения C# — от основ до продвинутых техник. Каждая книга прошла проверку временем и рекомендована профессиональными разработчиками.</p>
        </div>
        
        <!-- Первая книга: изображение слева -->
        <div class="book-container">
            <div class="book-image">
                <img src="book1.jpg" alt="CLR via C# Джеффри Рихтер">
            </div>
            <div class="book-text">
                <p class="h2">
                    <span class="book-number">1</span>
                    CLR via C# от Джеффри Рихтера
                </p>
                
                <div class="book-meta">
                    <div class="meta-item">
                        <span class="meta-icon"></span>
                        <strong>Автор:</strong> Джеффри Рихтер
                    </div>
                    <div class="meta-item">
                        <span class="meta-icon"></span>
                        <strong>Последнее издание:</strong> 4-е издание, 2020
                    </div>
                    <div class="meta-item">
                        <span class="meta-icon"></span>
                        <strong>Уровень:</strong> 
                        <span class="level-badge level-advanced">Продвинутый</span>
                    </div>
                </div>
                
                <p align="justify">Эта книга — must-have для любого серьёзного C# разработчика. Джеффри Рихтер, эксперт Microsoft, подробно объясняет внутреннее устройство Common Language Runtime (CLR) и платформы .NET. Книга охватывает все аспекты работы с CLR: управление памятью, многопоточность, сборку мусора, рефлексию, атрибуты и многое другое.</p>
                
                <p align="justify"><strong>Ключевые темы:</strong></p>
                <ul class="feature-list">
                    <li>Глубокое понимание системы типов .NET</li>
                    <li>Управление памятью и сборщик мусора</li>
                    <li>Многопоточность и синхронизация</li>
                    <li>Взаимодействие с неуправляемым кодом</li>
                    <li>Динамические сборки и рефлексия</li>
                </ul>
                
                <div class="quote">
                    "Понимание CLR — это то, что отделяет среднего разработчика C# от эксперта. Без этой книги ваше знание языка будет поверхностным."
                </div>
            </div>
        </div>

        <!-- Вторая книга: изображение справа -->
        <div class="book-container reverse">
            <div class="book-image">
                <img src="book2.jpg" alt="C# 11 and .NET 7 Марк Прайс">
            </div>
            <div class="book-text">
                <p class="h2">
                    <span class="book-number">2</span>
                    C# 11 and .NET 7 от Марка Прайса
                </p>
                
                <div class="book-meta">
                    <div class="meta-item">
                        <span class="meta-icon"></span>
                        <strong>Автор:</strong> Марк Прайс
                    </div>
                    <div class="meta-item">
                        <span class="meta-icon"></span>
                        <strong>Последнее издание:</strong> 7-е издание, 2023
                    </div>
                    <div class="meta-item">
                        <span class="meta-icon"></span>
                        <strong>Уровень:</strong> 
                        <span class="level-badge level-beginner">Начальный</span>
                        <span class="level-badge level-intermediate">Средний</span>
                    </div>
                </div>
                
                <p align="justify">Идеальная книга для начинающих и продолжающих разработчиков, желающих освоить современный C# 11 и .NET 7. Практический подход автора позволяет быстро перейти от теории к созданию реальных приложений. Книга постоянно обновляется и соответствует последним версиям технологий.</p>
                
                <p align="justify"><strong>Что вы освоите:</strong></p>
                <ul class="feature-list">
                    <li>Основы синтаксиса C# 11 и новые возможности языка</li>
                    <li>Создание веб-приложений с ASP.NET Core</li>
                    <li>Работа с базами данных через Entity Framework Core</li>
                    <li>Разработка кроссплатформенных приложений</li>
                    <li>Юнит-тестирование и отладка</li>
                    <li>Docker и облачные развертывания</li>
                </ul>
            </div>
        </div>

        <!-- Третья книга: изображение слева -->
        <div class="book-container">
            <div class="book-image">
                <img src="book3.jpg" alt="Concurrency in C# Cookbook Стивен Клири">
            </div>
            <div class="book-text">
                <p class="h2">
                    <span class="book-number">3</span>
                    Concurrency in C# Cookbook от Стивена Клири
                </p>
                
                <div class="book-meta">
                    <div class="meta-item">
                        <span class="meta-icon"></span>
                        <strong>Автор:</strong> Стивен Клири
                    </div>
                    <div class="meta-item">
                        <span class="meta-icon"></span>
                        <strong>Последнее издание:</strong> 2-е издание, 2019
                    </div>
                    <div class="meta-item">
                        <span class="meta-icon"></span>
                        <strong>Уровень:</strong> 
                        <span class="level-badge level-intermediate">Средний</span>
                        <span class="level-badge level-advanced">Продвинутый</span>
                    </div>
                </div>
                
                <p align="justify">Асинхронное и многопоточное программирование — одна из самых сложных тем в C#. Эта книга предлагает практические решения для реальных задач параллелизма. Формат "рецептов" позволяет быстро найти решение для конкретной проблемы, не читая всю книгу целиком.</p>
                
                <p align="justify"><strong>Основные разделы:</strong></p>
                <ul class="feature-list">
                    <li>Async/await и Task Parallel Library (TPL)</li>
                    <li>Параллельная обработка коллекций</li>
                    <li>Синхронизация и блокировки</li>
                    <li>Реактивное программирование (Rx.NET)</li>
                    <li>Асинхронные потоки (IAsyncEnumerable)</li>
                    <li>Dataflow и каналы (Channels)</li>
                </ul>
                
                <div class="quote">
                    "Многопоточность похожа на управление самолетом: если вы не знаете, что делаете, результаты могут быть катастрофическими. Эта книга — ваш инструктор по полетам."
                </div>
            </div>
        </div>

        <!-- Четвертая книга: изображение справа -->
        <div class="book-container reverse">
            <div class="book-image">
                <img src="book4.jpg" alt="Dependency Injection в .NET">
            </div>
            <div class="book-text">
                <p class="h2">
                    <span class="book-number">4</span>
                    Dependency Injection in .NET от Стивена ван Дейкена
                </p>
                
                <div class="book-meta">
                    <div class="meta-item">
                        <span class="meta-icon"></span>
                        <strong>Автор:</strong> Стивен ван Дейкен
                    </div>
                    <div class="meta-item">
                        <span class="meta-icon"></span>
                        <strong>Последнее издание:</strong> 1-е издание, 2019
                    </div>
                    <div class="meta-item">
                        <span class="meta-icon"></span>
                        <strong>Уровень:</strong> 
                        <span class="level-badge level-intermediate">Средний</span>
                    </div>
                </div>
                
                <p align="justify">Внедрение зависимостей (DI) — фундаментальный паттерн современной разработки на .NET. Эта книга учит правильно применять DI для создания поддерживаемого, тестируемого и гибкого кода. Особое внимание уделяется использованию встроенного контейнера .NET Core.</p>
                
                <p align="justify"><strong>Ключевые концепции:</strong></p>
                <ul class="feature-list">
                    <li>Принципы SOLID и их связь с DI</li>
                    <li>Паттерны внедрения зависимостей</li>
                    <li>Жизненные циклы сервисов</li>
                    <li>Интеграция с ASP.NET Core</li>
                    <li>Авторегистрация и сканирование сборок</li>
                    <li>Продвинутые сценарии DI</li>
                </ul>
            </div>
        </div>

        <!-- Пятая книга: изображение слева -->
        <div class="book-container">
            <div class="book-image">
                <img src="book5.jpg" alt="Pro .NET Memory Management">
            </div>
            <div class="book-text">
                <p class="h2">
                    <span class="book-number">5</span>
                    Pro .NET Memory Management от Конрада Кокосы
                </p>
                
                <div class="book-meta">
                    <div class="meta-item">
                        <span class="meta-icon"></span>
                        <strong>Автор:</strong> Конрад Кокоса
                    </div>
                    <div class="meta-item">
                        <span class="meta-icon"></span>
                        <strong>Последнее издание:</strong> 1-е издание, 2021
                    </div>
                    <div class="meta-item">
                        <span class="meta-icon"></span>
                        <strong>Уровень:</strong> 
                        <span class="level-badge level-advanced">Продвинутый</span>
                    </div>
                </div>
                
                <p align="justify">Для разработчиков, создающих высоконагруженные приложения, понимание управления памятью критически важно. Эта книга предоставляет глубокие знания о внутреннем устройстве сборщика мусора .NET и предлагает практические стратегии оптимизации производительности.</p>
                
                <p align="justify"><strong>Темы для экспертов:</strong></p>
                <ul class="feature-list">
                    <li>Архитектура сборщика мусора .NET 5+</li>
                    <li>Поколения объектов и Large Object Heap</li>
                    <li>Работа с Span&lt;T&gt; и Memory&lt;T&gt;</li>
                    <li>Диагностика утечек памяти</li>
                    <li>Производительность в облачных средах</li>
                    <li>Best practices для high-performance приложений</li>
                </ul>
            </div>
        </div>
    </div>
</main>

<footer class="footer">
    <div class="row">
        <div class="col">
            Техническая поддержка курсов: 8-800-300-22-88<br>
            Email: support@csharp-courses.ru | Бесплатные консультации по литературе
        </div>
    </div>
</footer>
</body>
</html>