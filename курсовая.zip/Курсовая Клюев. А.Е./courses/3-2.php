<?php
// 3-2.php - страница входа для курсов C#

require_once __DIR__ . '/src/helpers.php';

// Проверяем, не авторизован ли уже пользователь
if (isLoggedIn()) {
    redirect('3-3.php');
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Вход в аккаунт - Курсы C#</title>
    <style>
        :root {
            --dark-blue: #0a192f;
            --medium-blue: #172a45;
            --light-blue: #1d3657;
            --accent-blue: #64ffda;
            --text-light: #ccd6f6;
            --text-gray: #8892b0;
            --error-red: #ff6b6b;
        }
        
        * { 
            margin: 0; 
            padding: 0; 
            box-sizing: border-box; 
        }
        
        body { 
            font-family: 'Segoe UI', 'SF Pro Display', -apple-system, sans-serif; 
            background: linear-gradient(135deg, var(--dark-blue) 0%, #0d1b2a 100%);
            color: var(--text-light);
            min-height: 100vh;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        
        /* Шапка */
        .header {
            width: 100%;
            max-width: 500px;
            text-align: center;
            margin-bottom: 30px;
        }
        
        .header-logo {
            width: 80px;
            height: 80px;
            background: var(--medium-blue);
            border: 2px solid var(--accent-blue);
            border-radius: 12px;
            margin: 0 auto 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: bold;
            color: var(--accent-blue);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }
        
        .header h1 {
            color: var(--accent-blue);
            font-size: 24px;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        
        /* Контейнер логина */
        .login-box { 
            width: 100%;
            max-width: 450px;
            background: rgba(23, 42, 69, 0.9);
            padding: 40px 35px;
            border-radius: 15px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
            border: 1px solid rgba(100, 255, 218, 0.2);
            backdrop-filter: blur(10px);
            margin: 20px auto;
            transition: transform 0.3s ease;
        }
        
        .login-box:hover {
            transform: translateY(-5px);
        }
        
        h2 { 
            text-align: center; 
            color: var(--accent-blue); 
            margin-bottom: 30px; 
            font-size: 28px;
            font-weight: 700;
            position: relative;
            padding-bottom: 15px;
        }
        
        h2:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 60px;
            height: 3px;
            background: var(--accent-blue);
            border-radius: 2px;
        }
        
        .error { 
            background: rgba(255, 107, 107, 0.1); 
            color: var(--error-red); 
            padding: 15px; 
            border-radius: 8px; 
            margin-bottom: 25px; 
            text-align: center; 
            border: 1px solid rgba(255, 107, 107, 0.3);
            font-weight: 500;
            animation: fadeIn 0.3s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .form-group { 
            margin-bottom: 25px; 
        }
        
        label { 
            display: block; 
            margin-bottom: 10px; 
            color: var(--text-light); 
            font-weight: 500;
            font-size: 16px;
        }
        
        input { 
            width: 100%; 
            padding: 15px; 
            background: rgba(10, 25, 47, 0.6);
            border: 2px solid rgba(100, 255, 218, 0.2);
            border-radius: 8px; 
            font-size: 16px;
            color: var(--text-light);
            transition: all 0.3s ease;
            font-family: inherit;
        }
        
        input::placeholder {
            color: var(--text-gray);
            opacity: 0.7;
        }
        
        input:focus { 
            outline: none; 
            border-color: var(--accent-blue); 
            box-shadow: 0 0 0 3px rgba(100, 255, 218, 0.1);
            background: rgba(10, 25, 47, 0.8);
        }
        
        button { 
            width: 100%; 
            padding: 16px; 
            background: linear-gradient(135deg, var(--accent-blue) 0%, #52d4b4 100%);
            color: var(--dark-blue); 
            border: none; 
            border-radius: 10px; 
            cursor: pointer; 
            font-size: 18px; 
            font-weight: 700;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            margin-top: 10px;
        }
        
        button:hover { 
            background: linear-gradient(135deg, #73ffe0 0%, #52d4b4 100%);
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(100, 255, 218, 0.3);
        }
        
        button:active {
            transform: translateY(-1px);
        }
        
        /* Ссылки */
        .links { 
            text-align: center; 
            margin-top: 35px;
            padding-top: 25px;
            border-top: 1px solid rgba(100, 255, 218, 0.1);
        }
        
        .links p { 
            margin-bottom: 15px; 
            color: var(--text-gray);
            font-size: 15px;
        }
        
        .links a { 
            color: var(--accent-blue); 
            text-decoration: none; 
            font-weight: 600;
            transition: color 0.3s ease;
            position: relative;
            padding-bottom: 2px;
        }
        
        .links a:hover { 
            color: #8cfff0;
        }
        
        .links a:after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--accent-blue);
            transition: width 0.3s ease;
        }
        
        .links a:hover:after {
            width: 100%;
        }
        
        /* Иконка в поле ввода */
        .input-with-icon {
            position: relative;
        }
        
        .input-with-icon:before {
            content: attr(data-icon);
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--accent-blue);
            font-size: 18px;
        }
        
        .input-with-icon input {
            padding-left: 45px;
        }
        
        /* Сообщение о преимуществах */
        .benefits {
            background: rgba(100, 255, 218, 0.05);
            border-radius: 10px;
            padding: 20px;
            margin: 25px 0;
            border: 1px solid rgba(100, 255, 218, 0.1);
        }
        
        .benefits h3 {
            color: var(--accent-blue);
            font-size: 18px;
            margin-bottom: 10px;
            text-align: center;
        }
        
        .benefits ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .benefits li {
            color: var(--text-gray);
            margin: 8px 0;
            padding-left: 20px;
            position: relative;
            font-size: 14px;
        }
        
        .benefits li:before {
            content: '✓';
            color: var(--accent-blue);
            position: absolute;
            left: 0;
            font-weight: bold;
        }
        
        /* Адаптивность */
        @media (max-width: 768px) {
            .login-box {
                padding: 30px 25px;
                margin: 15px;
            }
            
            h2 {
                font-size: 24px;
                margin-bottom: 25px;
            }
            
            .header h1 {
                font-size: 20px;
            }
            
            .header-logo {
                width: 70px;
                height: 70px;
                font-size: 20px;
            }
        }
        
        @media (max-width: 480px) {
            body {
                padding: 15px;
            }
            
            .login-box {
                padding: 25px 20px;
            }
            
            input, button {
                padding: 14px;
            }
            
            .benefits {
                padding: 15px;
            }
        }
        
        /* Анимация загрузки */
        .loading {
            display: none;
            text-align: center;
            margin-top: 10px;
        }
        
        .loading-dot {
            display: inline-block;
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: var(--accent-blue);
            margin: 0 3px;
            animation: loading 1.4s infinite ease-in-out both;
        }
        
        .loading-dot:nth-child(1) { animation-delay: -0.32s; }
        .loading-dot:nth-child(2) { animation-delay: -0.16s; }
        
        @keyframes loading {
            0%, 80%, 100% { transform: scale(0); }
            40% { transform: scale(1); }
        }
    </style>
</head>
<body>
    <!-- Шапка -->
    <div class="header">
        <div class="header-logo">C#</div>
        <h1>Добро пожаловать на курсы C#</h1>
    </div>
    
    <!-- Контейнер логина -->
    <div class="login-box">
        <h2>Вход в аккаунт</h2>
        
        <?php if (isset($_SESSION['login_error'])): ?>
            <div class="error">
                <?= htmlspecialchars($_SESSION['login_error']) ?>
                <?php unset($_SESSION['login_error']); ?>
            </div>
        <?php endif; ?>
        
        <form action="src/actions/login.php" method="POST" id="loginForm">
            <div class="form-group input-with-icon" data-icon="">
                <label>Email для входа</label>
                <input type="email" name="email" 
                       value="<?= isset($_SESSION['old_login_email']) ? htmlspecialchars($_SESSION['old_login_email']) : '' ?>" 
                       placeholder="your.email@example.com"
                       required>
                <?php unset($_SESSION['old_login_email']); ?>
            </div>
            
            <div class="form-group input-with-icon" data-icon="">
                <label>Пароль</label>
                <input type="password" name="password" 
                       placeholder="Введите ваш пароль"
                       required>
            </div>
            
            <button type="submit" id="loginButton">Войти в систему</button>
            
            <div class="loading" id="loading">
                <div class="loading-dot"></div>
                <div class="loading-dot"></div>
                <div class="loading-dot"></div>
            </div>
        </form>
        
        <div class="links">
            <p>Нет аккаунта? <a href="3.php">Присоединиться к курсам</a></p>
            <p><a href="index.php">Вернуться на главную</a></p>
        </div>
    </div>
    
    <!-- Скрипт для анимации загрузки -->
    <script>
        document.getElementById('loginForm').addEventListener('submit', function() {
            var button = document.getElementById('loginButton');
            var loading = document.getElementById('loading');
            
            button.style.display = 'none';
            loading.style.display = 'block';
        });
    </script>
</body>
</html>