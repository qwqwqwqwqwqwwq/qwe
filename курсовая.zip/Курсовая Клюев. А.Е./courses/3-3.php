<?php
// 3-3.php - профиль пользователя с панелью администратора для курсов C#

require_once __DIR__ . '/src/actions/helpers.php';

// Проверяем авторизацию
if (!isLoggedIn()) {
    redirect('3.php');
}

$user = getCurrentUser();
$isAdmin = isAdmin();

// Получаем данные для админ панели (если админ)
$allUsers = [];
$stats = [];
if ($isAdmin) {
    $allUsers = getAllUsers();
    $stats = getStats();
}

// Обработка действий администратора
$action = isset($_GET['action']) ? $_GET['action'] : '';
$userId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$message = '';
$messageType = '';

// Удаление пользователя
if ($action === 'delete' && $userId && $isAdmin) {
    if (deleteUser($userId)) {
        $message = 'Пользователь успешно удален';
        $messageType = 'success';
    } else {
        $message = 'Ошибка при удалении пользователя';
        $messageType = 'error';
    }
}

// Обновление роли
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_role']) && $isAdmin) {
    $userId = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    $roleId = isset($_POST['role_id']) ? intval($_POST['role_id']) : 0;
    
    if (updateUserRole($userId, $roleId)) {
        $message = 'Роль пользователя обновлена';
        $messageType = 'success';
    } else {
        $message = 'Ошибка при обновлении роли';
        $messageType = 'error';
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Личный кабинет - <?= escape($user['name']) ?> | Курсы C#</title>
    <style>
        :root {
            --dark-blue: #0a192f;
            --medium-blue: #172a45;
            --light-blue: #1d3657;
            --accent-blue: #64ffda;
            --text-light: #ccd6f6;
            --text-gray: #8892b0;
            --error-red: #ff6b6b;
            --success-green: #48bb78;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', 'SF Pro Display', -apple-system, sans-serif;
            background: linear-gradient(135deg, var(--dark-blue) 0%, #0d1b2a 100%);
            color: var(--text-light);
            line-height: 1.6;
            min-height: 100vh;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        /* Шапка профиля - УВЕЛИЧЕННАЯ */
        .profile-header {
            background: linear-gradient(135deg, var(--medium-blue) 0%, var(--light-blue) 100%);
            color: var(--text-light);
            padding: 60px 30px;
            border-radius: 20px;
            margin-bottom: 40px;
            text-align: center;
            position: relative;
            border: 2px solid rgba(100, 255, 218, 0.3);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }
        
        .profile-header:before {
            content: '{ }';
            position: absolute;
            top: 20px;
            right: 20px;
            font-size: 40px;
            color: rgba(100, 255, 218, 0.1);
            font-weight: bold;
            font-family: 'Courier New', monospace;
        }
        
        .avatar {
            width: 150px;
            height: 150px;
            background: var(--dark-blue);
            border-radius: 50%;
            margin: 0 auto 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 60px;
            color: var(--accent-blue);
            font-weight: bold;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.4);
            border: 3px solid var(--accent-blue);
            font-family: 'Courier New', monospace;
        }
        
        .user-name {
            font-size: 42px;
            margin-bottom: 15px;
            font-weight: 700;
            color: var(--accent-blue);
            letter-spacing: 0.5px;
        }
        
        .user-email {
            font-size: 20px;
            color: var(--text-gray);
            margin-bottom: 30px;
            font-family: 'SF Mono', monospace;
        }
        
        .user-badge {
            display: inline-block;
            padding: 12px 30px;
            background: rgba(100, 255, 218, 0.15);
            border-radius: 25px;
            font-size: 16px;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: var(--accent-blue);
            border: 1px solid rgba(100, 255, 218, 0.3);
            backdrop-filter: blur(10px);
        }
        
        .admin-badge {
            background: rgba(220, 53, 69, 0.2);
            color: #ff6b6b;
            border-color: rgba(220, 53, 69, 0.3);
        }
        
        /* Навигация */
        .nav-menu {
            display: flex;
            gap: 15px;
            margin-bottom: 40px;
            flex-wrap: wrap;
            justify-content: center;
        }
        
        .nav-btn {
            padding: 15px 30px;
            background: rgba(23, 42, 69, 0.8);
            color: var(--text-gray);
            text-decoration: none;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid rgba(100, 255, 218, 0.1);
            display: flex;
            align-items: center;
            gap: 10px;
            backdrop-filter: blur(10px);
            letter-spacing: 0.5px;
        }
        
        .nav-btn:hover {
            background: rgba(100, 255, 218, 0.1);
            color: var(--accent-blue);
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(100, 255, 218, 0.1);
            border-color: rgba(100, 255, 218, 0.3);
        }
        
        .nav-btn.admin-btn {
            background: rgba(220, 53, 69, 0.2);
            color: #ff6b6b;
            border-color: rgba(220, 53, 69, 0.3);
        }
        
        .nav-btn.admin-btn:hover {
            background: rgba(220, 53, 69, 0.3);
            color: #ff6b6b;
            border-color: rgba(220, 53, 69, 0.5);
        }
        
        /* Основной контент - ТЕПЕРЬ ОДНА КОЛОНКА ПО ЦЕНТРУ */
        .profile-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 30px;
            margin-bottom: 40px;
            width: 100%;
        }
        
        /* Информация разработчика - УМЕНЬШЕННАЯ */
        .developer-info {
            background: rgba(23, 42, 69, 0.8);
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
            border: 1px solid rgba(100, 255, 218, 0.1);
            backdrop-filter: blur(10px);
            transition: transform 0.3s ease;
            width: 100%;
            max-width: 800px; /* Ограничиваем ширину */
            margin: 0 auto;
        }
        
        .developer-info:hover {
            transform: translateY(-5px);
            border-color: rgba(100, 255, 218, 0.3);
        }
        
        .developer-info h2 {
            color: var(--accent-blue);
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid rgba(100, 255, 218, 0.2);
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 24px;
            font-weight: 600;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        
        .info-item {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        
        .info-label {
            color: var(--text-gray);
            font-weight: 500;
            font-size: 14px;
        }
        
        .info-value {
            color: var(--text-light);
            font-weight: 600;
            font-family: 'SF Mono', monospace;
            font-size: 16px;
        }
        
        /* Панель администратора - ПО ЦЕНТРУ */
        .admin-section {
            margin-top: 40px;
            background: rgba(23, 42, 69, 0.9);
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(100, 255, 218, 0.2);
            width: 100%;
            max-width: 1000px; /* Центрируем */
            margin-left: auto;
            margin-right: auto;
        }
        
        .admin-header {
            background: linear-gradient(135deg, rgba(100, 255, 218, 0.2) 0%, rgba(23, 42, 69, 0.8) 100%);
            color: var(--accent-blue);
            padding: 25px 30px;
            display: flex;
            align-items: center;
            justify-content: center; /* Центрируем заголовок */
            gap: 20px;
            border-bottom: 1px solid rgba(100, 255, 218, 0.1);
            text-align: center;
        }
        
        .users-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .users-table th {
            background: rgba(10, 25, 47, 0.8);
            padding: 18px;
            text-align: left;
            font-weight: 600;
            color: var(--text-light);
            border-bottom: 2px solid rgba(100, 255, 218, 0.2);
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .users-table td {
            padding: 18px;
            border-bottom: 1px solid rgba(100, 255, 218, 0.1);
            color: var(--text-light);
        }
        
        .users-table tr:hover {
            background-color: rgba(100, 255, 218, 0.05);
        }
        
        .role-badge {
            display: inline-block;
            padding: 6px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .role-admin {
            background: rgba(220, 53, 69, 0.2);
            color: #ff6b6b;
            border: 1px solid rgba(220, 53, 69, 0.3);
        }
        
        .role-user {
            background: rgba(72, 187, 120, 0.2);
            color: #48bb78;
            border: 1px solid rgba(72, 187, 120, 0.3);
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
        }
        
        .action-btn {
            padding: 8px 15px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 600;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
            text-align: center;
            letter-spacing: 0.5px;
            text-transform: uppercase;
        }
        
        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        .btn-delete {
            background: rgba(220, 53, 69, 0.2);
            color: #ff6b6b;
            border: 1px solid rgba(220, 53, 69, 0.3);
        }
        
        /* Сообщения */
        .message {
            padding: 18px;
            border-radius: 10px;
            margin-bottom: 25px;
            text-align: center;
            font-weight: 600;
            animation: slideIn 0.5s ease;
            backdrop-filter: blur(10px);
            border: 1px solid;
            width: 100%;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }
        
        @keyframes slideIn {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        
        .success {
            background: rgba(72, 187, 120, 0.1);
            color: #48bb78;
            border-color: rgba(72, 187, 120, 0.3);
        }
        
        .error {
            background: rgba(255, 107, 107, 0.1);
            color: #ff6b6b;
            border-color: rgba(255, 107, 107, 0.3);
        }
        
        /* Статистика */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 25px;
            margin-top: 25px;
        }
        
        .stat-card {
            background: rgba(10, 25, 47, 0.6);
            padding: 25px;
            border-radius: 12px;
            text-align: center;
            border: 1px solid rgba(100, 255, 218, 0.1);
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            border-color: rgba(100, 255, 218, 0.3);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }
        
        .stat-number {
            font-size: 42px;
            font-weight: 700;
            color: var(--accent-blue);
            margin: 15px 0;
            font-family: 'SF Mono', monospace;
        }
        
        .stat-label {
            color: var(--text-gray);
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 600;
        }
        
        /* Футер */
        footer {
            text-align: center;
            margin-top: 60px;
            padding: 25px;
            color: var(--text-gray);
            border-top: 1px solid rgba(100, 255, 218, 0.1);
            font-size: 14px;
            backdrop-filter: blur(10px);
            border-radius: 10px;
            background: rgba(23, 42, 69, 0.5);
            width: 100%;
            max-width: 1000px;
            margin-left: auto;
            margin-right: auto;
        }
        
        /* Селект для ролей */
        select {
            background: rgba(10, 25, 47, 0.8);
            color: var(--text-light);
            border: 1px solid rgba(100, 255, 218, 0.3);
            border-radius: 6px;
            padding: 8px 12px;
            font-family: 'SF Mono', monospace;
            cursor: pointer;
            transition: all 0.3s;
            width: 100%;
            max-width: 150px;
        }
        
        select:focus {
            outline: none;
            border-color: var(--accent-blue);
            box-shadow: 0 0 0 3px rgba(100, 255, 218, 0.1);
        }
        
        /* Код для аватарки */
        .code-avatar {
            font-family: 'Courier New', monospace;
            font-size: 12px;
            color: var(--accent-blue);
            opacity: 0.8;
            margin-top: 5px;
        }
        
        /* Адаптивность */
        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }
            
            .profile-header {
                padding: 40px 20px;
            }
            
            .user-name {
                font-size: 32px;
            }
            
            .avatar {
                width: 120px;
                height: 120px;
                font-size: 48px;
            }
            
            .nav-menu {
                flex-direction: column;
            }
            
            .nav-btn {
                justify-content: center;
            }
            
            .users-table {
                display: block;
                overflow-x: auto;
            }
            
            .developer-info {
                padding: 20px;
            }
            
            .info-grid {
                grid-template-columns: 1fr;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .action-btn {
                width: 100%;
            }
            
            select {
                max-width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Шапка профиля -->
        <div class="profile-header">
            <div class="avatar">
                <?= strtoupper(mb_substr($user['name'], 0, 1, 'UTF-8')) ?>
            </div>
            <h1 class="user-name"><?= escape($user['name']) ?></h1>
            <p class="user-email"><?= escape($user['email']) ?></p>
            <div class="code-avatar">// C# Developer Profile</div>
            <span class="user-badge <?= $isAdmin ? 'admin-badge' : '' ?>">
                <?= $isAdmin ? 'Администратор курсов' : ' Ученик C#' ?>
            </span>
        </div>
        
        <!-- Навигация -->
        <div class="nav-menu">
            <a href="index.php" class="nav-btn"> Главная</a>
            <a href="1.php" class="nav-btn">История C#</a>
            <a href="2.php" class="nav-btn">Литература</a>
            <a href="4.php" class="nav-btn">Отзывы</a>
            <?php if ($isAdmin): ?>
                <a href="#admin-panel" class="nav-btn admin-btn">Панель администратора</a>
            <?php endif; ?>
            <a href="src/actions/logout.php" class="nav-btn" style="background: rgba(108, 117, 125, 0.3); border-color: rgba(108, 117, 125, 0.3); color: #adb5bd;">Выйти</a>
        </div>
        
        <!-- Сообщения -->
        <?php if ($message): ?>
            <div class="message <?= $messageType ?>">
                <?= escape($message) ?>
            </div>
        <?php endif; ?>
        
        <!-- Основная информация -->
        <div class="profile-content">
            <!-- Информация разработчика - УМЕНЬШЕННАЯ -->
            <div class="developer-info">
                <h2>👨‍💻 Информация разработчика</h2>
                <div class="info-grid">
                    <div class="info-item">
                        <span class="info-label">ID разработчика:</span>
                        <span class="info-value">#DEV<?= $user['user_id'] ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Имя:</span>
                        <span class="info-value"><?= escape($user['name']) ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Email:</span>
                        <span class="info-value"><?= escape($user['email']) ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Уровень доступа:</span>
                        <span class="info-value">
                            <span class="role-badge <?= $user['role_id'] == 1 ? 'role-admin' : 'role-user' ?>">
                                <?= $user['role_id'] == 1 ? 'Администратор' : 'Студент' ?>
                            </span>
                        </span>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Панель администратора (только для админов) -->
        <?php if ($isAdmin): ?>
            <div id="admin-panel" class="admin-section">
                <div class="admin-header">
                    <span style="font-size: 32px; font-family: 'Courier New', monospace;">{ }</span>
                    <h2 style="margin: 0;">Панель администратора курсов</h2>
                </div>
                
                <!-- Статистика -->
                <?php if (!empty($stats)): ?>
                    <div style="padding: 30px;">
                        <h3 style="color: var(--accent-blue); margin-bottom: 20px; text-align: center;">Статистика платформы</h3>
                        <div class="stats-grid">
                            <div class="stat-card">
                                <div class="stat-number"><?= isset($stats['total_users']) ? $stats['total_users'] : 0 ?></div>
                                <div class="stat-label">Всего студентов</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-number"><?= isset($stats['admins']) ? $stats['admins'] : 0 ?></div>
                                <div class="stat-label">Администраторов</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-number"><?= isset($stats['users']) ? $stats['users'] : 0 ?></div>
                                <div class="stat-label">Активных учеников</div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                
                <!-- Таблица пользователей -->
                <div style="padding: 30px;">
                    <h3 style="color: var(--accent-blue); margin-bottom: 25px; text-align: center;">Управление студентами</h3>
                    
                    <?php if (empty($allUsers)): ?>
                        <p style="text-align: center; color: var(--text-gray); padding: 20px;">Нет зарегистрированных студентов</p>
                    <?php else: ?>
                        <table class="users-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Имя</th>
                                    <th>Email</th>
                                    <th>Роль</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($allUsers as $otherUser): ?>
                                    <tr>
                                        <td>#DEV<?= $otherUser['user_id'] ?></td>
                                        <td>
                                            <?= escape($otherUser['name']) ?>
                                            <?php if ($otherUser['user_id'] == $user['user_id']): ?>
                                                <span style="color: var(--accent-blue); font-size: 12px; font-family: 'SF Mono', monospace;">// текущий</span>
                                            <?php endif; ?>
                                        </td>
                                        <td style="font-family: 'SF Mono', monospace;"><?= escape($otherUser['email']) ?></td>
                                        <td>
                                            <span class="role-badge <?= $otherUser['role_id'] == 1 ? 'role-admin' : 'role-user' ?>">
                                                <?= $otherUser['role_id'] == 1 ? 'Админ' : 'Студент' ?>
                                            </span>
                                            <form method="POST" action="" style="margin-top: 8px;">
                                                <input type="hidden" name="user_id" value="<?= $otherUser['user_id'] ?>">
                                                <select name="role_id" onchange="this.form.submit()" style="font-size: 13px; padding: 6px;">
                                                    <option value="1" <?= $otherUser['role_id'] == 1 ? 'selected' : '' ?>>Администратор</option>
                                                    <option value="2" <?= $otherUser['role_id'] == 2 ? 'selected' : '' ?>>Студент</option>
                                                </select>
                                                <input type="hidden" name="update_role" value="1">
                                            </form>
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <?php if ($otherUser['user_id'] != $user['user_id']): ?>
                                                    <a href="?action=delete&id=<?= $otherUser['user_id'] ?>" 
                                                       class="action-btn btn-delete"
                                                       onclick="return confirm('Удалить студента <?= escape($otherUser['name']) ?>? Это действие нельзя отменить.')">
                                                        Удалить
                                                    </a>
                                                <?php else: ?>
                                                    <span style="color: var(--text-gray); font-size: 12px; font-family: 'SF Mono', monospace;">// нельзя удалить</span>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
        
        <!-- Футер -->
        <footer>
            <p>Личный кабинет разработчика | Курсы C# программирования</p>
            <p style="margin-top: 10px; font-size: 12px; color: var(--text-gray); font-family: 'SF Mono', monospace;">
                &copy; <?= date('Y') ?> C# Courses. Все права защищены. <span style="color: var(--accent-blue);">// Code with passion</span>
            </p>
        </footer>
    </div>
    
    <script>
        // Автоматическое скрытие сообщений
        setTimeout(() => {
            const messages = document.querySelectorAll('.message');
            messages.forEach(msg => {
                msg.style.opacity = '0';
                msg.style.transition = 'opacity 0.5s';
                setTimeout(() => msg.remove(), 500);
            });
        }, 5000);
        
        // Плавная прокрутка к панели администратора
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const targetId = this.getAttribute('href');
                if (targetId !== '#') {
                    const targetElement = document.querySelector(targetId);
                    if (targetElement) {
                        targetElement.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                }
            });
        });
    </script>
</body>
</html>