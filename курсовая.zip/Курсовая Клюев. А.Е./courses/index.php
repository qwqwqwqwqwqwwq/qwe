<?php
// index.php — главная страница курсов C#
if (session_status() === PHP_SESSION_NONE) {
 session_start();
}

$isLoggedIn = isset($_SESSION['user']);
$userName = $isLoggedIn ? $_SESSION['user']['name'] : '';
?>

<!DOCTYPE html>
<html lang="ru">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>Курсы C# — Главная</title>
 <link rel="stylesheet" href="style.css">
 <style>
    :root {
        --dark-blue: #0a192f;
        --medium-blue: #172a45;
        --light-blue: #1d3657;
        --accent-blue: #64ffda;
        --text-light: #ccd6f6;
        --text-gray: #8892b0;
    }
 
 * {
 margin: 0;
 padding: 0;
 box-sizing: border-box;
 }
 
 body {
 font-family: 'Segoe UI', 'SF Pro Display', -apple-system, sans-serif;
 background: linear-gradient(135deg, var(--dark-blue) 0%, #0d1b2a 100%);
 color: var(--text-light);
 line-height: 1.6;
 }
 
 .container {
 max-width: 1200px;
 margin: 0 auto;
 padding: 0 20px;
 }
 
 header {
 background: linear-gradient(135deg, var(--medium-blue) 0%, var(--dark-blue) 100%);
 padding: 25px 0;
 border-bottom: 3px solid var(--accent-blue);
 box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
 }
 
 .header-content {
 display: flex;
 justify-content: space-between;
 align-items: center;
 }
 
 .logo h1 {
 color: var(--accent-blue);
 font-size: 32px;
 font-weight: 700;
 letter-spacing: 0.5px;
 text-shadow: 0 2px 10px rgba(100, 255, 218, 0.2);
 }
 
 .user-menu {
 display: flex;
 gap: 20px;
 align-items: center;
 }
 
 .user-menu a {
 color: var(--text-gray);
 text-decoration: none;
 padding: 10px 20px;
 border-radius: 8px;
 background: rgba(100, 255, 218, 0.1);
 transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
 border: 1px solid transparent;
 font-weight: 500;
 }
 
 .user-menu a:hover {
 background: rgba(100, 255, 218, 0.2);
 color: var(--accent-blue);
 border-color: rgba(100, 255, 218, 0.3);
 transform: translateY(-2px);
 box-shadow: 0 4px 15px rgba(100, 255, 218, 0.1);
 }
 
 .main-menu {
 background: rgba(23, 42, 69, 0.95);
 padding: 20px 0;
 backdrop-filter: blur(10px);
 border-bottom: 1px solid rgba(100, 255, 218, 0.1);
 }
 
 .main-menu ul {
 list-style: none;
 display: flex;
 justify-content: center;
 gap: 30px;
 flex-wrap: wrap;
 }
 
 .main-menu a {
 color: var(--text-gray);
 text-decoration: none;
 font-size: 18px;
 padding: 12px 25px;
 border-radius: 8px;
 transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
 border: 1px solid transparent;
 font-weight: 500;
 display: flex;
 align-items: center;
 gap: 10px;
 }
 
 .main-menu a:hover {
 background: rgba(100, 255, 218, 0.1);
 color: var(--accent-blue);
 border-color: rgba(100, 255, 218, 0.3);
 transform: translateY(-2px);
 }
 
 .hero {
 text-align: center;
 padding: 100px 20px;
 background: rgba(23, 42, 69, 0.8);
 margin: 40px 0;
 border-radius: 20px;
 border: 1px solid rgba(100, 255, 218, 0.2);
 box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
 backdrop-filter: blur(10px);
 position: relative;
 overflow: hidden;
 }
 
 .hero:before {
 content: '{ }';
 position: absolute;
 top: 20px;
 right: 20px;
 font-size: 60px;
 color: rgba(100, 255, 218, 0.1);
 font-weight: bold;
 font-family: 'Courier New', monospace;
 }
 
 .hero h2 {
 font-size: 48px;
 color: var(--accent-blue);
 margin-bottom: 25px;
 font-weight: 700;
 letter-spacing: 0.5px;
 }
 
 .hero p {
 font-size: 22px;
 color: var(--text-light);
 max-width: 800px;
 margin: 0 auto 40px;
 opacity: 0.9;
 line-height: 1.8;
 }
 
 .btn {
 display: inline-block;
 background: linear-gradient(135deg, var(--accent-blue) 0%, #52d4b4 100%);
 color: var(--dark-blue);
 padding: 16px 40px;
 border-radius: 50px;
 text-decoration: none;
 font-weight: 700;
 font-size: 18px;
 transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
 border: 2px solid transparent;
 letter-spacing: 0.5px;
 text-transform: uppercase;
 }
 
 .btn:hover {
 background: linear-gradient(135deg, #73ffe0 0%, #52d4b4 100%);
 transform: translateY(-3px);
 box-shadow: 0 10px 25px rgba(100, 255, 218, 0.3);
 }
 
 .features {
 display: grid;
 grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
 gap: 30px;
 margin: 60px 0;
 }
 
 .feature-card {
 background: rgba(23, 42, 69, 0.8);
 padding: 35px;
 border-radius: 15px;
 text-align: center;
 border: 1px solid rgba(100, 255, 218, 0.1);
 box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3);
 transition: all 0.3s ease;
 backdrop-filter: blur(10px);
 }
 
 .feature-card:hover {
 transform: translateY(-10px);
 border-color: var(--accent-blue);
 box-shadow: 0 20px 50px rgba(0, 0, 0, 0.4);
 }
 
 .feature-card h3 {
 color: var(--accent-blue);
 margin-bottom: 20px;
 font-size: 24px;
 font-weight: 600;
 }
 
 .feature-card p {
 color: var(--text-gray);
 line-height: 1.8;
 margin-bottom: 25px;
 }
 
 footer {
 background: linear-gradient(135deg, var(--medium-blue) 0%, var(--dark-blue) 100%);
 color: var(--text-gray);
 text-align: center;
 padding: 40px;
 margin-top: 80px;
 border-top: 3px solid var(--accent-blue);
 }
 
 .greeting {
 color: var(--accent-blue);
 font-weight: 600;
 font-size: 16px;
 background: rgba(100, 255, 218, 0.1);
 padding: 8px 16px;
 border-radius: 20px;
 border: 1px solid rgba(100, 255, 218, 0.2);
 }
 
 .user-btn {
 padding: 8px 16px;
 background: rgba(100, 255, 218, 0.15);
 color: var(--accent-blue);
 border-radius: 8px;
 text-decoration: none;
 font-weight: 600;
 transition: all 0.3s;
 border: 1px solid rgba(100, 255, 218, 0.2);
 }
 
 .user-btn:hover {
 background: rgba(100, 255, 218, 0.25);
 transform: translateY(-2px);
 }
 
 @media (max-width: 768px) {
 .header-content {
 flex-direction: column;
 gap: 20px;
 text-align: center;
 }
 
 .main-menu ul {
 flex-direction: column;
 align-items: center;
 gap: 15px;
 }
 
 .hero h2 {
 font-size: 36px;
 }
 
 .hero p {
 font-size: 18px;
 }
 
 .features {
 grid-template-columns: 1fr;
 }
 }
 
 .tech-badge {
 display: inline-block;
 background: rgba(100, 255, 218, 0.1);
 color: var(--accent-blue);
 padding: 4px 12px;
 border-radius: 15px;
 font-size: 12px;
 font-weight: 600;
 margin-left: 10px;
 vertical-align: middle;
 font-family: 'SF Mono', monospace;
 }
 
 .feature-card .btn {
 margin-top: 20px;
 padding: 12px 30px;
 font-size: 16px;
 background: rgba(100, 255, 218, 0.1);
 color: var(--accent-blue);
 border: 1px solid rgba(100, 255, 218, 0.3);
 }
 
 .feature-card .btn:hover {
 background: linear-gradient(135deg, var(--accent-blue) 0%, #52d4b4 100%);
 color: var(--dark-blue);
 }
 </style>
</head>
<body>
 <!-- Шапка с пользователем -->
 <header>
 <div class="container">
 <div class="header-content">
 <div class="logo">
 <h1>Курсы C# программирования <span class="tech-badge">.NET 8</span></h1>
 </div>
 <div class="user-menu">
 <?php if ($isLoggedIn): ?>
 <span class="greeting">Привет, <?= htmlspecialchars($userName) ?>!</span>
 <a href="3-3.php" class="user-btn">Профиль разработчика</a>
 <a href="src/actions/logout.php" class="user-btn">Выйти из системы</a>
 <?php else: ?>
 <a href="3.php" class="user-btn">Войти в систему</a>
 <a href="3.php" class="user-btn">Присоединиться к курсам</a>
 <?php endif; ?>
 </div>
 </div>
 </div>
 </header>
 
 <!-- Основное меню -->
 <nav class="main-menu">
 <div class="container">
 <ul>
 <li><a href="1.php">История языка C#</a></li>
 <li><a href="2.php">Литература по C#</a></li>
 <li><a href="4.php">Отзывы разработчиков</a></li>
 <?php if ($isLoggedIn && isset($_SESSION['user']['role_id']) && $_SESSION['user']['role_id'] == 1): ?>
 <li><a href="admin.php">Панель администратора</a></li>
 <?php endif; ?>
 </ul>
 </div>
 </nav>
 
 <!-- Основной контент -->
 <main class="container">
 <!-- Раздел с героем -->
 <section class="hero">
 <h2>Стань профессиональным C# разработчиком!</h2>
 <p>Освойте один из самых востребованных языков программирования с нуля до уровня Middle.</p>
 <a href="3.php" class="btn">Начать обучение бесплатно</a>
 </section>
 
 <!-- Карточки разделов -->
 <section class="features">
 <div class="feature-card">
 <h3>История языка C#</h3>
 <p>Узнайте эволюцию C# от создания до современных версий. Как язык стал кроссплатформенным и одним из самых популярных в enterprise-разработке.</p>
 <a href="1.php" class="btn">Изучить историю</a>
 </div>
 
 <div class="feature-card">
 <h3>Литература по C#</h3>
 <p>Подборка лучших книг для освоения C# — от основ до продвинутых техник. Must-read книги от признанных экспертов Microsoft.</p>
 <a href="2.php" class="btn">Посмотреть книги</a>
 </div>
 
 <div class="feature-card">
 <h3>Отзывы разработчиков</h3>
 <p>Реальные истории успеха наших выпускников. Узнайте, как C# помог изменить карьеру и достичь новых профессиональных высот.</p>
 <a href="4.php" class="btn">Читать отзывы</a>
 </div>
 
  </section>
 </main>
 
 <!-- Подвал -->
 <footer>
 <div class="container">
 <p style="font-size: 14px; margin-bottom: 10px; color: var(--accent-blue); font-weight: 600;">© 2026 Курсы C# программирования. Все права защищены.</p>
 <p style="font-size: 16px; margin-bottom: 15px;">Техническая поддержка курсов: 8-800-300-22-88 (круглосуточно)</p>
 <p style="font-size: 14px; color: var(--text-gray); font-family: 'SF Mono', monospace; margin-top: 10px;">
 // Официальный партнер Microsoft Learn • Подготовка к сертификации C# Developer
 </p>
 </div>
 </footer>
</body>
</html>