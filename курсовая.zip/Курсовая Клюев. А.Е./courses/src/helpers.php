<?php
// src/helpers.php

// Автоматически начинаем сессию
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Подключение к базе данных
 */
function getPDO() {
    try {
        // Прямые настройки (без config.php)
        $host = 'localhost';
        $dbname = 'courses';
        $username = 'root';
        $password = '';
        
        $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";
        $pdo = new PDO($dsn, $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $pdo;
    } catch (PDOException $e) {
        die("Ошибка подключения к базе данных: " . $e->getMessage());
    }
}

/**
 * Редирект
 */
function redirect($url) {
    header("Location: $url");
    exit();
}

/**
 * Проверка авторизации
 */
function isLoggedIn() {
    return isset($_SESSION['user']) && isset($_SESSION['user']['user_id']);
}

/**
 * Получение текущего пользователя
 */
function getCurrentUser() {
    return $_SESSION['user'] ?? null;
}

/**
 * Проверка гостя (неавторизованного пользователя)
 * Перенаправляет в профиль, если пользователь уже авторизован
 */
function checkGuest() {
    if (isLoggedIn()) {
        redirect('../../3-3.php');
    }
}

/**
 * Проверка авторизации пользователя
 * Перенаправляет на страницу входа, если не авторизован
 */
function checkAuth() {
    if (!isLoggedIn()) {
        redirect('../../3.php');
    }
}

/**
 * Выход из системы
 */
function logout() {
    unset($_SESSION['user']);
    session_destroy();
    redirect('../../index.php');
}

/**
 * Проверка, является ли текущий пользователь администратором
 */
function isAdmin() {
    $user = getCurrentUser();
    return isset($user['role_id']) && $user['role_id'] == 1;
}

/**
 * Получение всех пользователей (только для администратора) - БЕЗ created_at
 */
function getAllUsers() {
    if (!isAdmin()) {
        return [];
    }
    
    try {
        $pdo = getPDO();
        
        $stmt = $pdo->query("
            SELECT 
                user_id, 
                name, 
                email, 
                password, 
                role_id,
                CASE 
                    WHEN role_id = 1 THEN 'Администратор'
                    WHEN role_id = 2 THEN 'Пользователь'
                    ELSE 'Неизвестно'
                END as role_name
            FROM users 
            ORDER BY user_id ASC
        ");
        
        $users = $stmt->fetchAll();
        
        // Добавляем заглушку для даты регистрации
        foreach ($users as &$user) {
            $user['formatted_date'] = 'Не указана';
        }
        
        return $users;
        
    } catch (PDOException $e) {
        error_log("Ошибка при получении пользователей: " . $e->getMessage());
        return [];
    }
}

/**
 * Получение пользователя по ID (с проверкой прав)
 */
function getUserById($userId) {
    $pdo = getPDO();
    $stmt = $pdo->prepare("
        SELECT u.*, 
               CASE 
                   WHEN u.role_id = 1 THEN 'Администратор'
                   WHEN u.role_id = 2 THEN 'Пользователь'
                   ELSE 'Неизвестно'
               END as role_name
        FROM users u 
        WHERE u.user_id = ?
    ");
    $stmt->execute([$userId]);
    return $stmt->fetch();
}

/**
 * Удаление пользователя (только для администратора)
 */
function deleteUser($userId) {
    if (!isAdmin()) {
        return false;
    }
    
    // Нельзя удалить самого себя
    $currentUser = getCurrentUser();
    if ($currentUser && $currentUser['user_id'] == $userId) {
        return false;
    }
    
    try {
        $pdo = getPDO();
        $stmt = $pdo->prepare("DELETE FROM users WHERE user_id = ?");
        $stmt->execute([$userId]);
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        error_log("Ошибка удаления пользователя: " . $e->getMessage());
        return false;
    }
}

/**
 * Обновление роли пользователя
 */
function updateUserRole($userId, $roleId) {
    if (!isAdmin()) {
        return false;
    }
    
    try {
        $pdo = getPDO();
        $stmt = $pdo->prepare("UPDATE users SET role_id = ? WHERE user_id = ?");
        $stmt->execute([$roleId, $userId]);
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        error_log("Ошибка обновления роли: " . $e->getMessage());
        return false;
    }
}

/**
 * Получение статистики (для администратора)
 */
function getStats() {
    if (!isAdmin()) {
        return [];
    }
    
    $pdo = getPDO();
    
    $stats = [];
    
    try {
        // Общее количество пользователей
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM users");
        $stats['total_users'] = $stmt->fetchColumn();
        
        // Количество администраторов
        $stmt = $pdo->query("SELECT COUNT(*) as admins FROM users WHERE role_id = 1");
        $stats['admins'] = $stmt->fetchColumn();
        
        // Количество обычных пользователей
        $stmt = $pdo->query("SELECT COUNT(*) as users FROM users WHERE role_id = 2");
        $stats['users'] = $stmt->fetchColumn();
        
    } catch (PDOException $e) {
        // Если ошибка, устанавливаем значения по умолчанию
        $stats['total_users'] = 0;
        $stats['admins'] = 0;
        $stats['users'] = 0;
    }
    
    return $stats;
}

/**
 * Простая валидация email
 */
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * Хэширование пароля
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

/**
 * Проверка пароля
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Поиск пользователя по email
 */
function findUserByEmail($email) {
    $pdo = getPDO();
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    return $stmt->fetch();
}

/**
 * Проверка существования email в базе
 */
function checkEmailExists($email) {
    $pdo = getPDO();
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
    $stmt->execute([$email]);
    return $stmt->fetchColumn() > 0;
}

/**
 * Установка ошибки валидации
 */
function setValidationError($field, $message) {
    $_SESSION['validation'][$field] = $message;
}

/**
 * Проверка наличия ошибки валидации
 */
function hasValidationError($field) {
    return isset($_SESSION['validation'][$field]);
}

/**
 * Получение атрибута для ошибки валидации
 */
function validationErrorAttr($field) {
    return isset($_SESSION['validation'][$field]) ? 'aria-invalid="true"' : '';
}

/**
 * Получение сообщения об ошибке валидации
 */
function validationErrorMessage($field) {
    $message = $_SESSION['validation'][$field] ?? '';
    unset($_SESSION['validation'][$field]);
    return $message;
}

/**
 * Сохранение старого значения поля
 */
function setOldValue($key, $value) {
    $_SESSION['old'][$key] = $value;
}

/**
 * Получение старого значения поля
 */
function old($key) {
    $value = $_SESSION['old'][$key] ?? '';
    unset($_SESSION['old'][$key]);
    return $value;
}

/**
 * Установка сообщения
 */
function setMessage($type, $message) {
    $_SESSION['messages'][$type] = $message;
}

/**
 * Получение сообщения
 */
function getMessage($type) {
    $message = $_SESSION['messages'][$type] ?? '';
    unset($_SESSION['messages'][$type]);
    return $message;
}

/**
 * Проверка наличия сообщения
 */
function hasMessage($type) {
    return isset($_SESSION['messages'][$type]);
}

/**
 * Загрузка файла
 */
function uploadFile($file, $prefix = '') {
    $uploadDir = __DIR__ . '/../uploads/';
    
    // Создаем папку, если не существует
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    
    // Генерируем уникальное имя файла
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $fileName = $prefix . '_' . time() . '_' . uniqid() . '.' . $extension;
    $filePath = $uploadDir . $fileName;
    
    // Перемещаем файл
    if (move_uploaded_file($file['tmp_name'], $filePath)) {
        return 'uploads/' . $fileName;
    }
    
    return null;
}

/**
 * Получение роли пользователя
 */
function getUserRole() {
    $user = getCurrentUser();
    return $user['role_id'] ?? 2; // По умолчанию обычный пользователь
}

/**
 * Защита от XSS
 */
function escape($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

/**
 * Форматирование даты
 */
function formatDate($date, $format = 'd.m.Y H:i') {
    if (empty($date) || $date === '0000-00-00 00:00:00') {
        return 'Не указана';
    }
    return date($format, strtotime($date));
}

/**
 * Отладка (для разработки)
 */
function dd($data) {
    echo '<pre>';
    print_r($data);
    echo '</pre>';
    die();
}
?>