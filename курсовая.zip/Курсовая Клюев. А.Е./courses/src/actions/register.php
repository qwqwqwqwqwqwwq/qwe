<?php
// src/actions/register.php

// Начинаем сессию
session_start();

// Подключаем helpers
require_once __DIR__ . '/../helpers.php';

// Получаем данные из формы
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$passwordConfirmation = $_POST['password_confirmation'] ?? '';

// Массив для ошибок
$errors = [];

// Валидация
if (empty($name)) {
    $errors['name'] = 'Введите ваше имя';
}

if (empty($email)) {
    $errors['email'] = 'Введите email';
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors['email'] = 'Введите корректный email';
}

if (empty($password)) {
    $errors['password'] = 'Введите пароль';
} elseif (strlen($password) < 6) {
    $errors['password'] = 'Пароль должен быть не менее 6 символов';
}

if ($password !== $passwordConfirmation) {
    $errors['password_confirmation'] = 'Пароли не совпадают';
}

// Если есть ошибки, сохраняем их и возвращаем
if (!empty($errors)) {
    $_SESSION['validation'] = $errors;
    $_SESSION['old']['name'] = $name;
    $_SESSION['old']['email'] = $email;
    header("Location: ../../3.php");
    exit();
}

// Подключаемся к базе данных
try {
    $pdo = getPDO();
    
    // Проверяем, есть ли уже пользователь с таким email
    $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
    $checkStmt->execute([$email]);
    
    if ($checkStmt->fetchColumn() > 0) {
        $errors['email'] = 'Пользователь с таким email уже существует';
        $_SESSION['validation'] = $errors;
        $_SESSION['old']['name'] = $name;
        $_SESSION['old']['email'] = $email;
        header("Location: ../../3.php");
        exit();
    }
    
    // Хэшируем пароль
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    // Вставляем нового пользователя
    $sql = "INSERT INTO users (name, email, password, role_id) VALUES (?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$name, $email, $hashedPassword, 2]);
    
    // Получаем ID нового пользователя
    $userId = $pdo->lastInsertId();
    
    // Получаем данные пользователя
    $userStmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
    $userStmt->execute([$userId]);
    $user = $userStmt->fetch(PDO::FETCH_ASSOC);
    
    // Сохраняем пользователя в сессии
    $_SESSION['user'] = [
        'user_id' => $user['user_id'],
        'name' => $user['name'],
        'email' => $user['email'],
        'role_id' => $user['role_id']
    ];
    
    // Редирект на страницу профиля
    header("Location: ../../3-3.php");
    exit();
    
} catch (PDOException $e) {
    // Если ошибка базы данных
    die("Ошибка при регистрации: " . $e->getMessage());
}
?>