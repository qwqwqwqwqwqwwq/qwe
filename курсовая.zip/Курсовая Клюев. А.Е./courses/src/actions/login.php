<?php
// src/actions/login.php

require_once __DIR__ . '/../helpers.php';

checkGuest();

// Получаем данные
$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

// Валидация
if (empty($email) || empty($password)) {
    $_SESSION['login_error'] = 'Заполните все поля';
    $_SESSION['old_login_email'] = $email;
    redirect('../../3-2.php');
}

try {
    $pdo = getPDO();
    
    // Ищем пользователя
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if (!$user) {
        $_SESSION['login_error'] = 'Пользователь с таким email не найден';
        $_SESSION['old_login_email'] = $email;
        redirect('../../3-2.php');
    }
    
    // ВАЖНО: Проверяем пароль как обычный текст
    // потому что в вашей базе пароли не хэшированы
    if ($password === $user['password']) {
        // Успешный вход
        $_SESSION['user'] = [
            'user_id' => $user['user_id'],
            'name' => $user['name'],
            'email' => $user['email'],
            'role_id' => $user['role_id']
        ];
        
        // Очищаем ошибки
        unset($_SESSION['login_error']);
        unset($_SESSION['old_login_email']);
        
        redirect('../../3-3.php');
    } else {
        $_SESSION['login_error'] = 'Неверный пароль';
        $_SESSION['old_login_email'] = $email;
        redirect('../../3-2.php');
    }
    
} catch (PDOException $e) {
    $_SESSION['login_error'] = 'Ошибка базы данных. Попробуйте позже.';
    redirect('../../3-2.php');
}
?>