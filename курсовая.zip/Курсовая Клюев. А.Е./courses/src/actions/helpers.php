<?php
// helpers.php - СОВМЕСТИМАЯ ВЕРСИЯ ДЛЯ PHP 7.x
// Этот файл должен быть сохранен в UTF-8 без BOM

// ВСЕГДА ПЕРВОЕ ДЕЛО - буферизация
ob_start();

// ПРОСТОЙ вызов session_start() без сложных проверок
if (!isset($_SESSION)) {
    @session_start();
}

// Подключаем config.php
require_once __DIR__ . '/config.php';

// Простые функции без сложных проверок
function redirect($path)
{
    // Очищаем буфер
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    
    // Простой редирект
    header("Location: " . $path);
    exit();
}

function setValidationError($fieldName, $message)
{
    $_SESSION['validation'][$fieldName] = $message;
}

function hasValidationError($fieldName)
{
    return !empty($_SESSION['validation'][$fieldName]);
}

function validationErrorAttr($fieldName)
{
    return !empty($_SESSION['validation'][$fieldName]) ? 'aria-invalid="true"' : '';
}

function validationErrorMessage($fieldName)
{
    $message = $_SESSION['validation'][$fieldName] ?? '';
    unset($_SESSION['validation'][$fieldName]);
    return $message;
}

function setOldValue($key, $value)
{
    $_SESSION['old'][$key] = $value;
}

function old($key)
{
    $value = $_SESSION['old'][$key] ?? '';
    unset($_SESSION['old'][$key]);
    return $value;
}

function uploadFile($file, $prefix = '')
{
    $uploadPath = __DIR__ . '/../uploads';

    if (!is_dir($uploadPath)) {
        mkdir($uploadPath, 0777, true);
    }

    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $fileName = $prefix . '_' . time() . ".$ext";

    if (!move_uploaded_file($file['tmp_name'], "$uploadPath/$fileName")) {
        die('Ошибка при загрузке файла на сервер');
    }

    return "uploads/$fileName";
}

function setMessage($key, $message)
{
    $_SESSION['message'][$key] = $message;
}

function hasMessage($key)
{
    return !empty($_SESSION['message'][$key]);
}

function getMessage($key)
{
    $message = $_SESSION['message'][$key] ?? '';
    unset($_SESSION['message'][$key]);
    return $message;
}

function getPDO()
{
    try {
        $pdo = new PDO(
            'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';charset=utf8;dbname=' . DB_NAME,
            DB_USERNAME,
            DB_PASSWORD
        );
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        die("Ошибка базы данных: " . htmlspecialchars($e->getMessage()));
    }
}

function findUser($email)
{
    $pdo = getPDO();
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->execute(['email' => $email]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result ? $result : [];
}

function currentUser()
{
    if (empty($_SESSION['user']['user_id'])) {
        return false;
    }

    $userId = $_SESSION['user']['user_id'];
    $pdo = getPDO();
    $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = :id");
    $stmt->execute(['id' => $userId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result ? $result : false;
}

function logout()
{
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
    redirect('/');
}

function checkAuth()
{
    if (empty($_SESSION['user']['user_id'])) {
        redirect('3-2.php');
    }
}

function checkGuest()
{
    if (!empty($_SESSION['user']['user_id'])) {
        redirect('3-3.php');
    }
}

function getAllUsers()
{
    $pdo = getPDO();
    $stmt = $pdo->query("SELECT * FROM users");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function deleteUser($userId)
{
    $pdo = getPDO();
    try {
        $stmt = $pdo->prepare("DELETE FROM users WHERE user_id = :user_id");
        return $stmt->execute(['user_id' => $userId]);
    } catch (PDOException $e) {
        return false;
    }
}

function updateUserRole($userId, $roleId)
{
    $pdo = getPDO();
    try {
        $stmt = $pdo->prepare("UPDATE users SET role_id = :role_id WHERE user_id = :user_id");
        return $stmt->execute(['role_id' => $roleId, 'user_id' => $userId]);
    } catch (PDOException $e) {
        return false;
    }
}

function getAllRoles()
{
    $pdo = getPDO();
    $stmt = $pdo->query("SELECT * FROM roles ORDER BY role_id");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getStats()
{
    $pdo = getPDO();
    $stats = [];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total_users FROM users");
    $stats['total_users'] = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as admins FROM users WHERE role_id = 1");
    $stmt->execute();
    $stats['admins'] = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as users FROM users WHERE role_id = 2");
    $stmt->execute();
    $stats['users'] = $stmt->fetchColumn();
    
    return $stats;
}

function isLoggedIn()
{
    return !empty($_SESSION['user']['user_id']);
}

function isAdmin()
{
    return !empty($_SESSION['user']['role_id']) && $_SESSION['user']['role_id'] == 1;
}

function getCurrentUser()
{
    return isset($_SESSION['user']) ? $_SESSION['user'] : null;
}

function escape($string)
{
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

// Функция для безопасного вывода сессионных данных
function session($key, $default = '')
{
    return isset($_SESSION[$key]) ? $_SESSION[$key] : $default;
}

// Функция для безопасного получения POST данных
function post($key, $default = '')
{
    return isset($_POST[$key]) ? htmlspecialchars($_POST[$key]) : $default;
}

// Функция для безопасного получения GET данных
function get($key, $default = '')
{
    return isset($_GET[$key]) ? htmlspecialchars($_GET[$key]) : $default;
}