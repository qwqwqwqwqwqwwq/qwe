<?php
// Начинаем сессию в самом начале файла
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Подключаем helpers.php для использования функций
require_once __DIR__ . '/src/actions/helpers.php';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="style.css">
    <title>Отзывы о C# | Курсы программирования</title>
    <style>
        :root {
            --dark-blue: #0a192f;
            --medium-blue: #172a45;
            --light-blue: #1d3657;
            --accent-blue: #64ffda;
            --text-light: #ccd6f6;
            --text-gray: #8892b0;
            --quote-bg: rgba(23, 42, 69, 0.5);
        }
        
        body {
            background: linear-gradient(135deg, var(--dark-blue) 0%, #0d1b2a 100%);
            color: var(--text-light);
            font-family: 'Segoe UI', 'SF Pro Display', -apple-system, sans-serif;
            min-height: 100vh;
            margin: 0;
            line-height: 1.6;
        }
        
        header {
            background: linear-gradient(135deg, var(--medium-blue) 0%, #0d1b2a 100%);
            padding: 1.5rem 0;
            border-bottom: 2px solid var(--accent-blue);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
            text-align: center; /* Добавлено: центрирование заголовка */
        }
        
        .logo img {
            height: 70px;
            border-radius: 10px;
            border: 2px solid var(--accent-blue);
            padding: 3px;
            background: white;
        }
        
        .title h1 {
            color: var(--accent-blue);
            font-size: 2.3rem;
            font-weight: 700;
            letter-spacing: 0.5px;
            text-shadow: 0 2px 10px rgba(100, 255, 218, 0.2);
            width: 100%; /* Добавлено: занимает всю ширину */
            text-align: center; /* Добавлено: центрирование текста */
            margin: 0; /* Добавлено: убираем отступы по умолчанию */
        }
        
        .nav {
            background: rgba(23, 42, 69, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            padding: 0.5rem;
            margin: 1.5rem auto;
            max-width: 1200px;
            border: 1px solid rgba(100, 255, 218, 0.1);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }
        
        .nav-link {
            color: var(--text-gray) !important;
            background: transparent;
            margin: 0 4px;
            border-radius: 8px;
            border: 1px solid transparent;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            font-weight: 500;
            padding: 0.8rem 1.8rem;
        }
        
        .nav-link:hover {
            color: var(--accent-blue) !important;
            transform: translateY(-2px);
            border-color: rgba(100, 255, 218, 0.3);
            box-shadow: 0 4px 15px rgba(100, 255, 218, 0.1);
        }
        
        .nav-link.active {
            background: rgba(100, 255, 218, 0.1) !important;
            color: var(--accent-blue) !important;
            border-color: var(--accent-blue);
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .display-7 {
            color: var(--accent-blue);
            font-size: 2.8rem;
            text-align: center;
            margin: 3rem 0 2rem;
            position: relative;
            padding-bottom: 1.5rem;
        }
        
        .display-7:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 150px;
            height: 3px;
            background: var(--accent-blue);
            border-radius: 2px;
        }
        
        /* Стили цитат из первого кода */
        .quote-container {
            background: rgba(23, 42, 69, 0.8);
            border-radius: 15px;
            padding: 40px 35px;
            margin: 30px 0;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3);
            border-left: 6px solid var(--accent-blue);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(100, 255, 218, 0.1);
        }
        
        .quote-container:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.4);
            border-left: 6px solid var(--accent-blue);
            border-color: rgba(100, 255, 218, 0.3);
        }
        
        .quote-text {
            font-size: 1.4rem;
            line-height: 1.8;
            color: var(--text-light);
            font-style: italic;
            margin-bottom: 25px;
            text-align: center;
            padding: 0 20px;
        }
        
        .quote-author {
            font-size: 1.2rem;
            color: var(--accent-blue);
            text-align: right;
            font-weight: 600;
            padding-right: 20px;
            border-top: 1px solid rgba(100, 255, 218, 0.2);
            padding-top: 20px;
        }
        
        .quote-category {
            display: inline-block;
            background: rgba(100, 255, 218, 0.1);
            color: var(--accent-blue);
            padding: 8px 20px;
            border-radius: 20px;
            font-size: 0.9rem;
            margin-bottom: 20px;
            font-weight: 600;
            letter-spacing: 0.5px;
            border: 1px solid rgba(100, 255, 218, 0.2);
        }
        
        /* Информация о пользователе из второго кода */
        .user-info {
            display: flex;
            align-items: center;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid rgba(100, 255, 218, 0.1);
        }
        
        .user-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--accent-blue), #4fd1c7);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            font-weight: bold;
            color: var(--dark-blue);
            margin-right: 1.5rem;
            font-family: 'Courier New', monospace;
        }
        
        .user-details {
            flex: 1;
        }
        
        .user-name {
            color: var(--accent-blue);
            font-weight: 600;
            font-size: 1.1rem;
            margin-bottom: 0.3rem;
        }
        
        .user-position {
            color: var(--text-gray);
            font-size: 0.95rem;
        }
        
        .rating {
            color: #ffd700;
            font-size: 1.2rem;
            letter-spacing: 2px;
            margin-top: 5px;
        }
        
        .quote-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 1rem;
            color: var(--text-gray);
            font-size: 0.9rem;
        }
        
        .industry-tag {
            display: inline-block;
            padding: 0.3rem 1rem;
            background: rgba(100, 255, 218, 0.1);
            color: var(--accent-blue);
            border-radius: 20px;
            font-size: 0.85rem;
            margin-left: 0.5rem;
            font-weight: 500;
        }
        
        .row {
            padding: 1rem 0;
        }
        
        .col {
            padding: 0 1rem;
        }
        
        .flex {
            display: flex;
            flex-direction: column;
        }
        
        .footer {
            background: linear-gradient(135deg, var(--medium-blue) 0%, var(--dark-blue) 100%);
            color: var(--text-gray);
            padding: 2.5rem 0;
            margin-top: 4rem;
            border-top: 2px solid var(--accent-blue);
            text-align: center;
            font-size: 1.1rem;
        }
        
        .intro-text {
            text-align: center;
            color: var(--text-gray);
            font-size: 1.2rem;
            max-width: 800px;
            margin: 0 auto 3rem;
            line-height: 1.8;
            padding: 0 1rem;
        }
        
        @media (max-width: 768px) {
            .quote-container {
                padding: 25px 20px;
                margin: 25px 0;
            }
            
            .quote-text {
                font-size: 1.2rem;
                padding: 0 10px;
            }
            
            .display-7 {
                font-size: 2.2rem;
                padding: 0 1rem;
            }
            
            .title h1 {
                font-size: 1.8rem;
            }
            
            .nav-link {
                padding: 0.6rem 1.2rem;
                margin: 2px;
            }
            
            .user-info {
                flex-direction: column;
                text-align: center;
            }
            
            .user-avatar {
                margin-right: 0;
                margin-bottom: 15px;
            }
        }
        
        /* Эффект для кавычек */
        .quote-container:before {
            content: '"';
            position: absolute;
            top: -15px;
            left: 30px;
            font-size: 5rem;
            color: rgba(100, 255, 218, 0.15);
            font-family: Georgia, serif;
            font-weight: bold;
        }
        
        .quote-container {
            position: relative;
        }
    </style>
</head>
<body class="body-top">
<header class="container">
    <div class="row">
        <!-- ЛОГОТИП УДАЛЕН -->
        <div class="title">
            <h1>Стань профессионалом в C# разработке!</h1>
        </div>
    </div>
</header>

<div id="menu">
    <nav class="nav nav-pills flex-column flex-sm-row">
        <a class="flex-sm-fill text-sm-center nav-link" href="index.php">Главная</a>
        <a class="flex-sm-fill text-sm-center nav-link" href="1.php">История языка</a>
        <a class="flex-sm-fill text-sm-center nav-link active" href="4.php">Отзывы о языке C#</a>
        <a class="flex-sm-fill text-sm-center nav-link" href="2.php">Литература по C#</a>
        <?php if (isset($_SESSION['user']['user_id'])) : ?>
            <a class="flex-sm-fill text-sm-center nav-link" href="3-3.php"><?= htmlspecialchars($_SESSION['user']['name']) ?></a>
        <?php else : ?>
            <a class="flex-sm-fill text-sm-center nav-link" href="3.php">Войти/Зарегистрироваться</a>
        <?php endif; ?>
</nav>
</div>

<main class="flex">
    <div class="container">
        <h1 class="display-7">Отзывы разработчиков о языке C#</h1>
        
        <p class="intro-text">
            Узнайте, что говорят профессиональные разработчики о своём опыте работы с C#. 
            Реальные истории, советы и мнения от тех, кто ежедневно использует этот язык в production.
        </p>

        <!-- Первый отзыв -->
        <div class="quote-container">
            <div class="quote-category">Создатель C#</div>
            <div class="quote-text">
                C# — это золотая середина между производительностью и удобством разработки. 
                После 10 лет работы с разными языками я осознал, что C# предоставляет идеальный баланс 
                строгой типизации, современных возможностей и богатой экосистемы. Особенно ценю 
                постоянное развитие языка — каждая новая версия приносит что-то действительно полезное.
            </div>
            <div class="quote-meta">
                <div class="quote-author">Андерс Хейлсберг</div>
                <div class="industry-tag">Создатель C#</div>
            </div>
            <div class="user-info">
                <div class="user-avatar">AH</div>
                <div class="user-details">
                    <div class="user-name">Андерс Хейлсберг</div>
                    <div class="user-position">Technical Fellow в Microsoft, Создатель C# и TypeScript</div>
                    <div class="rating">★★★★★</div>
                </div>
            </div>
        </div>

        <!-- Второй отзыв -->
        <div class="quote-container">
            <div class="quote-category">Backend разработка</div>
            <div class="quote-text">
                Переход с Java на C# был одним из лучших решений в моей карьере. 
                LINQ, async/await, record types — эти возможности кардинально изменили мой подход к программированию. 
                Производительность .NET Core поражает, особенно в облачных сценариях. 
                Для enterprise-разработки сейчас нет ничего лучше стека C# + .NET.
            </div>
            <div class="quote-meta">
                <div class="quote-author">Мария Семёнова</div>
                <div class="industry-tag">Senior Backend Developer</div>
            </div>
            <div class="user-info">
                <div class="user-avatar">MS</div>
                <div class="user-details">
                    <div class="user-name">Мария Семёнова</div>
                    <div class="user-position">Senior Backend Developer в крупной IT-компании, 8 лет опыта</div>
                    <div class="rating">★★★★★</div>
                </div>
            </div>
        </div>

        <!-- Третий отзыв -->
        <div class="quote-container">
            <div class="quote-category">Управление проектами</div>
            <div class="quote-text">
                Как руководитель отдела разработки, я ценю C# за предсказуемость и поддерживаемость кода. 
                Проекты на C# масштабируются значительно лучше благодаря строгой типизации и отличной инструментальной поддержке. 
                Новые разработчики вливаются в проект быстрее, а качество кода остаётся высоким даже в больших командах.
            </div>
            <div class="quote-meta">
                <div class="quote-author">Дмитрий Волков</div>
                <div class="industry-tag">Tech Lead</div>
            </div>
            <div class="user-info">
                <div class="user-avatar">ДВ</div>
                <div class="user-details">
                    <div class="user-name">Дмитрий Волков</div>
                    <div class="user-position">Tech Lead в банковском секторе, 12 лет в разработке</div>
                    <div class="rating">★★★★☆</div>
                </div>
            </div>
        </div>

        <!-- Четвертый отзыв -->
        <div class="quote-container">
            <div class="quote-category">Начинающий разработчик</div>
            <div class="quote-text">
                Начал изучать C# как первый язык программирования и не пожалел. 
                Синтаксис интуитивно понятен, сообщество активно помогает, а документация Microsoft — одна из лучших в индустрии. 
                Через полгода обучения смог устроиться на первую работу. Сейчас, спустя 3 года, 
                веду собственный проект на ASP.NET Core и зарабатываю в 3 раза больше, чем на предыдущей работе.
            </div>
            <div class="quote-meta">
                <div class="quote-author">Алексей Петров</div>
                <div class="industry-tag">Выпускник курсов</div>
            </div>
            <div class="user-info">
                <div class="user-avatar">АП</div>
                <div class="user-details">
                    <div class="user-name">Алексей Петров</div>
                    <div class="user-position">Middle .NET Developer, выпускник 2022 года</div>
                    <div class="rating">★★★★★</div>
                </div>
            </div>
        </div>

        <!-- Пятый отзыв -->
        <div class="quote-container">
            <div class="quote-category">Game Development</div>
            <div class="quote-text">
                Для геймдева C# через Unity — это стандарт индустрии. 
                За 5 лет работы над мобильными играми я оценил, насколько продуктивным может быть этот стек. 
                Производительность, кроссплатформенность и богатая экосистема ассетов делают C# идеальным выбором 
                для инди-разработчиков и крупных студий.
            </div>
            <div class="quote-meta">
                <div class="quote-author">Екатерина Смирнова</div>
                <div class="industry-tag">Game Developer</div>
            </div>
            <div class="user-info">
                <div class="user-avatar">ЕС</div>
                <div class="user-details">
                    <div class="user-name">Екатерина Смирнова</div>
                    <div class="user-position">Lead Game Developer в игровой студии</div>
                    <div class="rating">★★★★★</div>
                </div>
            </div>
        </div>

        <!-- Шестой отзыв -->
        <div class="quote-container">
            <div class="quote-category">Ветеран разработки</div>
            <div class="quote-text">
                Работаю с C# с 2005 года и наблюдал эволюцию языка от простого ООП языка до современной платформы. 
                Особенно впечатляет путь к кроссплатформенности — сегодня я могу разрабатывать на C# под любую ОС. 
                Для молодых разработчиков это отличный выбор: рынок труда насыщен вакансиями, а зарплаты растут.
            </div>
            <div class="quote-meta">
                <div class="quote-author">Сергей Иванов</div>
                <div class="industry-tag">Software Architect</div>
            </div>
            <div class="user-info">
                <div class="user-avatar">СИ</div>
                <div class="user-details">
                    <div class="user-name">Сергей Иванов</div>
                    <div class="user-position">Software Architect, 18 лет в разработке</div>
                    <div class="rating">★★★★★</div>
                </div>
            </div>
        </div>
    </div>
</main>

<footer class="footer">
    <div class="row">
        <div class="col">
            Техническая поддержка курсов: 8-800-300-22-88<br>
            Email: support@csharp-courses.ru | Присоединяйтесь к нашему сообществу разработчиков
        </div>
    </div>
</footer>
</body>
</html>