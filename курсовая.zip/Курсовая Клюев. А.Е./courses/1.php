<?php
// Начинаем сессию в самом начале файла
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Подключаем helpers.php для использования функций
require_once __DIR__ . '/src/actions/helpers.php';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
    <title>Курсы C# | Программирование</title>
    <style>
        :root {
            --dark-blue: #0a192f;
            --medium-blue: #172a45;
            --light-blue: #1d3657;
            --accent-blue: #64ffda;
            --text-light: #ccd6f6;
            --text-gray: #8892b0;
        }
        
        .body-top {
            background: linear-gradient(135deg, var(--dark-blue) 0%, #0d1b2a 100%);
            color: var(--text-light);
            font-family: 'Segoe UI', 'SF Pro Display', -apple-system, sans-serif;
            min-height: 100vh;
            line-height: 1.6;
        }
        
        header {
            background: linear-gradient(135deg, var(--medium-blue) 0%, var(--dark-blue) 100%);
            padding: 1.5rem 0;
            border-bottom: 2px solid var(--accent-blue);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
            text-align: center; /* Добавлено: центрирование заголовка */
        }
        
        .title h1 {
            color: var(--accent-blue);
            font-size: 2.3rem;
            font-weight: 700;
            letter-spacing: 0.5px;
            text-shadow: 0 2px 10px rgba(100, 255, 218, 0.2);
            width: 100%; /* Добавлено: занимает всю ширину */
            text-align: center; /* Добавлено: центрирование текста */
            margin: 0; /* Добавлено: убираем отступы по умолчанию */
        }
        
        .nav {
            background: rgba(23, 42, 69, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            padding: 0.5rem;
            margin: 1.5rem auto;
            max-width: 1200px;
            border: 1px solid rgba(100, 255, 218, 0.1);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }
        
        .nav-link {
            color: var(--text-gray) !important;
            background: transparent;
            margin: 0 4px;
            border-radius: 8px;
            border: 1px solid transparent;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            font-weight: 500;
            padding: 0.8rem 1.8rem;
        }
        
        .nav-link:hover {
            color: var(--accent-blue) !important;
            transform: translateY(-2px);
            border-color: rgba(100, 255, 218, 0.3);
            box-shadow: 0 4px 15px rgba(100, 255, 218, 0.1);
        }
        
        .nav-link.active {
            background: rgba(100, 255, 218, 0.1) !important;
            color: var(--accent-blue) !important;
            border-color: var(--accent-blue);
        }
        
        main {
            background: rgba(10, 25, 47, 0.7);
            padding: 2.5rem;
            border-radius: 20px;
            margin: 1.5rem auto;
            max-width: 1200px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(100, 255, 218, 0.1);
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        }
        
        .display-5 {
            color: var(--accent-blue);
            font-size: 3rem;
            margin-bottom: 2.5rem;
            padding-bottom: 1.5rem;
            border-bottom: 2px solid rgba(100, 255, 218, 0.3);
            text-align: center;
            position: relative;
        }
        
        .display-5:after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 50%;
            transform: translateX(-50%);
            width: 150px;
            height: 3px;
            background: var(--accent-blue);
            border-radius: 2px;
        }
        
        .h2 {
            color: var(--accent-blue);
            font-size: 2rem;
            margin: 2.5rem 0 1.5rem;
            padding-left: 1rem;
            border-left: 4px solid var(--accent-blue);
            font-weight: 600;
        }
        
        p {
            color: var(--text-gray);
            line-height: 1.8;
            font-size: 1.15rem;
            margin-bottom: 1.5rem;
        }
        
        /* Стили для статей из первого кода */
        .article-container {
            display: flex;
            align-items: flex-start;
            margin-bottom: 50px;
            flex-wrap: wrap;
            padding: 30px;
            background: rgba(23, 42, 69, 0.4);
            border-radius: 15px;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
            border: 1px solid rgba(100, 255, 218, 0.1);
            transition: transform 0.3s ease;
        }
        
        .article-container:hover {
            transform: translateY(-5px);
            border-color: var(--accent-blue);
        }
        
        .article-text {
            flex: 1;
            min-width: 300px;
            padding: 0 30px;
        }
        
        .article-image {
            max-width: 450px;
            min-width: 350px;
        }
        
        .article-image img {
            width: 100%;
            height: auto;
            border-radius: 12px;
            border: 2px solid rgba(100, 255, 218, 0.3);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
            transition: transform 0.3s ease;
        }
        
        .article-image img:hover {
            transform: scale(1.03);
            border-color: var(--accent-blue);
        }
        
        .reverse {
            flex-direction: row-reverse;
        }
        
        .quote-box {
            background: linear-gradient(145deg, rgba(23, 42, 69, 0.6), rgba(10, 25, 47, 0.8));
            border-left: 4px solid var(--accent-blue);
            padding: 2rem;
            margin: 2.5rem 0;
            border-radius: 0 15px 15px 0;
            font-style: italic;
            color: var(--text-light);
            font-size: 1.2rem;
            line-height: 1.7;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }
        
        .quote-author {
            text-align: right;
            color: var(--accent-blue);
            font-weight: 600;
            margin-top: 1rem;
            font-size: 1.1rem;
        }
        
        .version-badge {
            display: inline-block;
            background: rgba(100, 255, 218, 0.1);
            color: var(--accent-blue);
            padding: 0.5rem 1.2rem;
            border-radius: 20px;
            font-size: 0.95rem;
            font-weight: 600;
            margin-right: 0.8rem;
            margin-bottom: 0.8rem;
            border: 1px solid rgba(100, 255, 218, 0.3);
        }
        
        .feature-list {
            list-style-type: none;
            padding-left: 0;
            margin: 1.5rem 0;
        }
        
        .feature-list li {
            margin: 0.8rem 0;
            padding-left: 2rem;
            position: relative;
            color: var(--text-light);
        }
        
        .feature-list li:before {
            content: "▸";
            color: var(--accent-blue);
            position: absolute;
            left: 0;
            font-size: 1.2rem;
        }
        
        .highlight {
            color: var(--accent-blue);
            font-weight: 600;
            background: rgba(100, 255, 218, 0.1);
            padding: 0.2rem 0.5rem;
            border-radius: 4px;
        }
        
        strong {
            color: var(--accent-blue);
        }
        
        .footer {
            background: linear-gradient(135deg, var(--medium-blue) 0%, var(--dark-blue) 100%);
            color: var(--text-gray);
            padding: 2.5rem 0;
            margin-top: 4rem;
            border-top: 2px solid var(--accent-blue);
            text-align: center;
            font-size: 1.1rem;
        }
        
        @media (max-width: 768px) {
            .article-container, .article-container.reverse {
                flex-direction: column;
                padding: 20px;
            }
            
            .article-image, .article-text {
                width: 100%;
                max-width: 100%;
                padding: 0;
                margin-bottom: 20px;
            }
            
            .article-image {
                min-width: 100%;
            }
            
            .display-5 {
                font-size: 2.2rem;
            }
            
            .h2 {
                font-size: 1.6rem;
            }
            
            .nav-link {
                padding: 0.6rem 1.2rem;
                margin: 2px;
            }
            
            main {
                padding: 1.5rem;
                margin: 1rem;
            }
        }
        
        .flex {
            display: flex;
            flex-direction: column;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .row {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            padding: 1.5rem 0;
        }
        
        .col {
            flex: 1;
            padding: 1rem;
        }
    </style>
</head>
<body class="body-top">
<header class="container">
    <!-- ЛОГОТИП УДАЛЕН -->
    <div class="title">
        <h1>Стань востребованным C# разработчиком!</h1>
    </div>
</header>

<div id="menu">
    <nav class="nav nav-pills flex-column flex-sm-row">
        <a class="flex-sm-fill text-sm-center nav-link" href="index.php">Главная</a>
        <a class="flex-sm-fill text-sm-center nav-link active" href="1.php">История языка</a>
        <a class="flex-sm-fill text-sm-center nav-link" href="4.php">Отзывы о языке C#</a>
        <a class="flex-sm-fill text-sm-center nav-link" href="2.php">Литература по C#</a>
        <?php if (isset($_SESSION['user']['user_id'])) : ?>
            <a class="flex-sm-fill text-sm-center nav-link" href="3-3.php"><?= htmlspecialchars($_SESSION['user']['name']) ?></a>
        <?php else : ?>
            <a class="flex-sm-fill text-sm-center nav-link" href="3.php">Войти/Зарегистрироваться</a>
        <?php endif; ?>
    </nav>
</div>

<main class="flex">
    <div class="container">
        <h1 class="display-5">История языка C#: от создания до современности</h1>
        
        <!-- Первая статья: изображение слева -->
        <div class="article-container">
            <div class="article-image">
                <img src="img1.jpg" alt="Андерс Хейлсберг - создатель C#">
            </div>
            <div class="article-text">
                <p class="h2">Зарождение языка: ответ Microsoft на Java</p>
                <p align="justify">В конце 1990-х годов, когда Java набирала популярность благодаря своей платформенной независимости и объектно-ориентированному подходу, Microsoft осознала необходимость создания современного языка программирования для своей платформы .NET. Проект начался в 1999 году под кодовым названием <span class="highlight">"Cool"</span> (C-like Object Oriented Language).</p>
                
                <div class="quote-box">
                    "Мы хотели создать язык, который был бы простым, современным, объектно-ориентированным и типобезопасным. C# должен был объединить лучшие черты C++ и Java, избегая их недостатков."
                    <div class="quote-author">— Андерс Хейлсберг, создатель C#</div>
                </div>
                
                <p align="justify">Главным архитектором языка стал <span class="highlight">Андерс Хейлсберг</span>, датский инженер-программист, ранее работавший над Turbo Pascal, Delphi и Visual J++. Его опыт сыграл ключевую роль в формировании философии C#.</p>
                
                <p class="h2">2000-2002: Рождение C#</p>
                <span class="version-badge">C# 1.0</span>
                <p align="justify">Первая версия языка была представлена в июне 2000 года вместе с анонсом платформы .NET Framework. Основные особенности:</p>
                <ul class="feature-list">
                    <li><strong>Полностью объектно-ориентированный дизайн</strong></li>
                    <li><strong>Управляемый код с автоматической сборкой мусора</strong></li>
                    <li><strong>Безопасность типов</strong></li>
                    <li><strong>Делегаты и события</strong></li>
                    <li><strong>Свойства, индексаторы, атрибуты</strong></li>
                </ul>
            </div>
        </div>

        <!-- Вторая статья: изображение справа -->
        <div class="article-container reverse">
            <div class="article-image">
                <img src="img2.jpg" alt="Развитие платформы .NET">
            </div>
            <div class="article-text">
                <p class="h2">Эволюция языка: от C# 2.0 до 5.0</p>
                
                <p class="h2">2005: C# 2.0 — Generics и многое другое</p>
                <span class="version-badge">C# 2.0</span>
                <p align="justify">Второй мажорный релиз принёс революционные изменения:</p>
                <ul class="feature-list">
                    <li><strong>Обобщённые типы (Generics)</strong> — повышение типобезопасности и производительности</li>
                    <li><strong>Анонимные методы</strong></li>
                    <li><strong>Итераторы с ключевым словом yield</strong></li>
                    <li><strong>Частичные классы (partial)</strong></li>
                    <li><strong>Nullable типы</strong></li>
                </ul>
                
                <p class="h2">2007: C# 3.0 — LINQ и функциональные возможности</p>
                <span class="version-badge">C# 3.0</span>
                <p align="justify">Самое значительное обновление в истории языка:</p>
                <ul class="feature-list">
                    <li><strong>LINQ (Language Integrated Query)</strong> — революционный подход к работе с данными</li>
                    <li><strong>Лямбда-выражения</strong></li>
                    <li><strong>Неявно типизированные переменные (var)</strong></li>
                    <li><strong>Инициализаторы объектов и коллекций</strong></li>
                    <li><strong>Анонимные типы</strong></li>
                    <li><strong>Методы расширения</strong></li>
                </ul>
                
                <p class="h2">2010: C# 4.0 — динамическое программирование</p>
                <span class="version-badge">C# 4.0</span>
                <p align="justify">Фокус на взаимодействие с динамическими языками:</p>
                <ul class="feature-list">
                    <li><strong>Динамическое связывание (dynamic)</strong></li>
                    <li><strong>Именованные и необязательные параметры</strong></li>
                    <li><strong>Ковариантность и контравариантность</strong></li>
                    <li><strong>Улучшенная COM-взаимодействие</strong></li>
                </ul>
            </div>
        </div>

        <!-- Третья статья: изображение слева -->
        <div class="article-container">
            <div class="article-image">
                <img src="img3.jpg" alt="Сообщество C# разработчиков">
            </div>
            <div class="article-text">
                <p class="h2">Современная эра C# и будущее языка</p>
                
                <p class="h2">2012-2015: Асинхронность и качество жизни</p>
                <span class="version-badge">C# 5.0</span>
                <p align="justify">Эпоха асинхронного программирования:</p>
                <ul class="feature-list">
                    <li><strong>Async/await</strong> — упрощение асинхронного кода</li>
                    <li><strong>Информация о вызывающем объекте (Caller Info attributes)</strong></li>
                </ul>
                
                <span class="version-badge">C# 6.0</span>
                <p align="justify">Множество мелких улучшений для разработчиков:</p>
                <ul class="feature-list">
                    <li><strong>Инициализаторы свойств с помощью get-only</strong></li>
                    <li><strong>Выражения для методов и свойств</strong></li>
                    <li><strong>Интерполяция строк ($"...")</strong></li>
                    <li><strong>Null-условный оператор (?.)</strong></li>
                    <li><strong>Импорт статических классов</strong></li>
                </ul>
                
                <p class="h2">2017-2023: C# 7.x — 11.0</p>
                <span class="version-badge">C# 7.0-11.0</span>
                <p align="justify">Быстрая итерация с ежегодными обновлениями:</p>
                <ul class="feature-list">
                    <li><strong>Кортежи и деконструкция (C# 7.0)</strong></li>
                    <li><strong>Сопоставление с образцом (pattern matching)</strong></li>
                    <li><strong>Локальные функции</strong></li>
                    <li><strong>Readonly struct и ref struct</strong></li>
                    <li><strong>Интерфейсы с реализацией по умолчанию</strong></li>
                    <li><strong>Записи (records) и init-only свойства</strong></li>
                    <li><strong>Пространства имён в файлах (C# 10)</strong></li>
                    <li><strong>Необработанные строковые литералы (C# 11)</strong></li>
                </ul>
                
                <div class="quote-box">
                    "C# перестал быть просто языком для Windows. Сегодня это универсальный язык для любых задач — от встраиваемых систем до облачных микросервисов, от игр до веб-приложений."
                    <div class="quote-author">— Скотт Хансельман, Microsoft</div>
                </div>
                
                <p class="h2">Заключение</p>
                <p align="justify">За более чем два десятилетия C# превратился из ответа Microsoft на Java в один из самых современных, мощных и востребованных языков программирования. Его философия постоянного совершенствования, внимание к потребностям разработчиков и способность адаптироваться к меняющимся технологическим ландшафтам делают C# отличным выбором как для начинающих, так и для опытных программистов.</p>
                
                <p align="justify">На наших курсах вы не только изучите современный C# 11, но и поймёте его философию, узнаете лучшие практики и сможете стать частью этого динамично развивающегося сообщества.</p>
            </div>
        </div>
    </div>
</main>

<footer class="footer">
    <div class="row">
        <div class="col">
            Техническая поддержка курсов: 8-800-300-22-88<br>
            Email: support@csharp-courses.ru | © 2026 Курсы C#
        </div>
    </div>
</footer>
</body>
</html>