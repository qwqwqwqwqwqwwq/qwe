<?php
// 3.php - страница регистрации и входа для курсов C#
// Начинаем сессию в самом начале файла
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Если пользователь уже авторизован, перенаправляем в профиль
if (isset($_SESSION['user']['user_id'])) {
    header("Location: 3-3.php");
    exit();
}

// Подключаем helpers.php для использования функций
require_once __DIR__ . '/src/helpers.php';
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="style.css">
    <title>Вход / Регистрация - Курсы C#</title>
    <style>
        :root {
            --dark-blue: #0a192f;
            --medium-blue: #172a45;
            --light-blue: #1d3657;
            --accent-blue: #64ffda;
            --text-light: #ccd6f6;
            --text-gray: #8892b0;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', 'SF Pro Display', -apple-system, sans-serif;
            background: linear-gradient(135deg, var(--dark-blue) 0%, #0d1b2a 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            color: var(--text-light);
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        
        /* Навигация */
        header {
            background: linear-gradient(135deg, var(--medium-blue) 0%, var(--dark-blue) 100%);
            padding: 1.5rem 0;
            border-bottom: 2px solid var(--accent-blue);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
            text-align: center; /* Добавлено: центрирование заголовка */
        }
        
        .logo img {
            height: 70px;
            border-radius: 10px;
            border: 2px solid var(--accent-blue);
            padding: 3px;
            background: white;
        }
        
        .title h1 {
            color: var(--accent-blue);
            font-size: 2.3rem;
            font-weight: 700;
            letter-spacing: 0.5px;
            text-shadow: 0 2px 10px rgba(100, 255, 218, 0.2);
            width: 100%; /* Добавлено: занимает всю ширину */
            text-align: center; /* Добавлено: центрирование текста */
            margin: 0; /* Добавлено: убираем отступы по умолчанию */
        }
        
        .nav {
            background: rgba(23, 42, 69, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            padding: 0.5rem;
            margin: 1.5rem auto;
            max-width: 1200px;
            border: 1px solid rgba(100, 255, 218, 0.1);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }
        
        .nav-link {
            color: var(--text-gray) !important;
            background: transparent;
            margin: 0 4px;
            border-radius: 8px;
            border: 1px solid transparent;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            font-weight: 500;
            padding: 0.8rem 1.8rem;
        }
        
        .nav-link:hover {
            color: var(--accent-blue) !important;
            transform: translateY(-2px);
            border-color: rgba(100, 255, 218, 0.3);
            box-shadow: 0 4px 15px rgba(100, 255, 218, 0.1);
        }
        
        .nav-link.active {
            background: rgba(100, 255, 218, 0.1) !important;
            color: var(--accent-blue) !important;
            border-color: var(--accent-blue);
        }
        
        /* Карточка формы */
        .card {
            background: rgba(23, 42, 69, 0.9);
            padding: 50px;
            border-radius: 15px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
            width: 100%;
            max-width: 550px;
            border: 1px solid rgba(100, 255, 218, 0.2);
            backdrop-filter: blur(10px);
            margin: 20px;
        }
        
        .reg {
            text-align: center;
            color: var(--accent-blue);
            margin-bottom: 40px;
            font-size: 32px;
            font-weight: 700;
            letter-spacing: 0.5px;
            position: relative;
            padding-bottom: 20px;
        }
        
        .reg:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background: var(--accent-blue);
            border-radius: 2px;
        }
        
        .reg2 {
            display: block;
            margin-bottom: 25px;
            color: var(--text-light);
            font-weight: 500;
            font-size: 16px;
        }
        
        input {
            width: 100%;
            padding: 15px;
            margin-top: 8px;
            background: rgba(10, 25, 47, 0.6);
            border: 2px solid rgba(100, 255, 218, 0.2);
            border-radius: 8px;
            font-size: 16px;
            color: var(--text-light);
            transition: all 0.3s ease;
        }
        
        input::placeholder {
            color: var(--text-gray);
            opacity: 0.7;
        }
        
        input:focus {
            outline: none;
            border-color: var(--accent-blue);
            box-shadow: 0 0 0 3px rgba(100, 255, 218, 0.1);
            background: rgba(10, 25, 47, 0.8);
        }
        
        .grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
        }
        
        small {
            color: #ff6b6b;
            font-size: 14px;
            display: block;
            margin-top: 8px;
            font-weight: 500;
        }
        
        .btn1 {
            display: block;
            width: 100%;
            max-width: 350px;
            padding: 18px;
            background: linear-gradient(135deg, var(--accent-blue) 0%, #52d4b4 100%);
            color: var(--dark-blue);
            border: none;
            border-radius: 10px;
            font-size: 18px;
            font-weight: 700;
            cursor: pointer;
            margin: 40px auto 0 auto;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            text-align: center;
            letter-spacing: 0.5px;
            text-transform: uppercase;
        }
        
        .btn1:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(100, 255, 218, 0.3);
            background: linear-gradient(135deg, #73ffe0 0%, #52d4b4 100%);
        }
        
        .btn1:active {
            transform: translateY(-1px);
        }
        
        p {
            text-align: center;
            margin-top: 30px;
            color: var(--text-gray);
            font-size: 16px;
        }
        
        a {
            color: var(--accent-blue);
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s ease;
            position: relative;
        }
        
        a:hover {
            color: #8cfff0;
            text-decoration: none;
        }
        
        a:after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--accent-blue);
            transition: width 0.3s ease;
        }
        
        a:hover:after {
            width: 100%;
        }
        
        /* Стили для центрирования формы */
        .form-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
        }
        
        .form-fields {
            width: 100%;
        }
        
        /* Дополнительный текст */
        .form-footer {
            text-align: center;
            margin: 30px 0;
            padding: 20px;
            background: rgba(100, 255, 218, 0.05);
            border-radius: 10px;
            border: 1px solid rgba(100, 255, 218, 0.1);
        }
        
        .form-footer p {
            margin: 0;
            font-size: 15px;
            line-height: 1.6;
        }
        
        @media (max-width: 768px) {
            .grid {
                grid-template-columns: 1fr;
                gap: 20px;
            }
            
            .card {
                padding: 35px;
                margin: 15px;
            }
            
            .nav {
                flex-direction: column;
                align-items: center;
                padding: 0.3rem;
            }
            
            .nav-link {
                width: 100%;
                text-align: center;
                margin: 3px 0;
                padding: 0.7rem;
            }
            
            .btn1 {
                max-width: 100%;
                padding: 16px;
            }
            
            .reg {
                font-size: 28px;
                margin-bottom: 35px;
            }
            
            .title h1 {
                font-size: 1.8rem;
            }
        }
        
        @media (max-width: 480px) {
            .card {
                padding: 25px;
                margin: 10px;
            }
            
            input {
                padding: 12px;
                font-size: 15px;
            }
            
            .btn1 {
                padding: 14px;
                font-size: 16px;
            }
            
            .reg {
                font-size: 24px;
                margin-bottom: 30px;
            }
        }
        
        .row {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            padding: 1.5rem 0;
        }
        
        .col {
            flex: 1;
            padding: 1rem;
        }
        
        .flex {
            display: flex;
            flex-direction: column;
        }
    </style>
</head>
<body class="body-top">
    <!-- Шапка без логотипа -->
    <header class="container">
        <!-- ЛОГОТИП УДАЛЕН -->
        <div class="title">
            <h1>Стань востребованным C# разработчиком!</h1>
        </div>
    </header>
    
    <!-- Меню навигации -->
    <div id="menu">
        <nav class="nav nav-pills flex-column flex-sm-row">
            <a class="flex-sm-fill text-sm-center nav-link" href="index.php">Главная</a>
            <a class="flex-sm-fill text-sm-center nav-link" href="1.php">История языка</a>
            <a class="flex-sm-fill text-sm-center nav-link" href="4.php">Отзывы о языке C#</a>
            <a class="flex-sm-fill text-sm-center nav-link" href="2.php">Литература по C#</a>
            
            <?php if (isset($_SESSION['user']['user_id'])) : ?>
                <a class="flex-sm-fill text-sm-center nav-link" href="3-3.php"><?= htmlspecialchars($_SESSION['user']['name']) ?></a>
            <?php else : ?>
                <a class="flex-sm-fill text-sm-center nav-link active" href="3.php">Войти/Зарегистрироваться</a>
            <?php endif; ?>
        </nav>
    </div>
    
    <!-- Основной контейнер -->
    <div class="container">
        <div class="card">
            <!-- Форма регистрации -->
            <div class="form-container">
                <h2 class="reg">Присоединиться к курсам C#</h2>
                
                <form action="src/actions/register.php" method="post" class="form-fields">
                    <!-- Поле имени -->
                    <label class="reg2">
                        Ваше имя
                        <input
                            type="text"
                            id="name"
                            name="name"
                            placeholder="например, Алексей"
                            value="<?php echo old('name'); ?>"
                            <?php echo validationErrorAttr('name'); ?>
                        >
                        <?php if(hasValidationError('name')): ?>
                            <small><?php echo validationErrorMessage('name'); ?></small>
                        <?php endif; ?>
                    </label>
                    
                    <!-- Поле email -->
                    <label class="reg2">
                        E-mail для доступа
                        <input
                            type="email"
                            id="email"
                            name="email"
                            placeholder="your.email@example.com"
                            value="<?php echo old('email'); ?>"
                            <?php echo validationErrorAttr('email'); ?>
                        >
                        <?php if(hasValidationError('email')): ?>
                            <small><?php echo validationErrorMessage('email'); ?></small>
                        <?php endif; ?>
                    </label>
                    
                    <!-- Пароль и подтверждение -->
                    <div class="grid">
                        <label class="reg2">
                            Пароль
                            <input
                                type="password"
                                id="password"
                                name="password"
                                placeholder="Не менее 6 символов"
                                <?php echo validationErrorAttr('password'); ?>
                            >
                            <?php if(hasValidationError('password')): ?>
                                <small><?php echo validationErrorMessage('password'); ?></small>
                            <?php endif; ?>
                        </label>
                        
                        <label class="reg2">
                            Подтверждение пароля
                            <input
                                type="password"
                                id="password_confirmation"
                                name="password_confirmation"
                                placeholder="Повторите пароль"
                            >
                        </label>
                    </div>
                    
                    <!-- Кнопка регистрации -->
                    <button class="btn1" type="submit" id="submit">
                        Начать обучение
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Ссылка на вход -->
    <div style="text-align: center; margin: 40px auto;">
        <p>Уже учитесь у нас? <a href="3-2.php">Войти в аккаунт</a></p>
        <p style="margin-top: 15px; font-size: 14px; color: var(--text-gray);">
            Регистрируясь, вы соглашаетесь с условиями использования и политикой конфиденциальности
        </p>
    </div>
</body>
</html>